'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { ensureDataDir, readJSON, writeJSON } = require('./auth');
const { tzForProvince } = require('./models');

// Conversation memory store.
// Mechanism: each conversation has a stable conversation_id that gets sent as metadata
// to the API so the backend keeps one thread per conversation (less forgetting).

function conversationsDir() {
  const dir = path.join(__dirname, '..', 'data', 'conversations');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function newConversationId() {
  return 'cx_' + crypto.randomBytes(12).toString('hex');
}

function startConversation(model, province) {
  const dir = conversationsDir();
  const id = newConversationId();
  const conv = {
    id,
    model,
    province: province || 'default',
    tz: tzForProvince(province),
    createdAt: new Date().toISOString(),
    messages: [
      {
        role: 'system',
        content:
          'You are CodinX, a powerful terminal-based AI agent. You can use tools (file creation, table generation, markdown rendering, web fetch, command execution) when the user grants permission. Always be concise and helpful. When you need to run a tool, output a tool-call block in the format <<<TOOL:toolname>>>{...args}<<<END>>> and wait for the user to approve.',
      },
    ],
  };
  writeJSON(path.join(dir, id + '.json'), conv);
  return conv;
}

function loadConversation(id) {
  const file = path.join(conversationsDir(), id + '.json');
  return readJSON(file, null);
}

function saveConversation(conv) {
  const file = path.join(conversationsDir(), conv.id + '.json');
  writeJSON(file, conv);
}

function appendMessage(conv, role, content) {
  conv.messages.push({ role, content, ts: new Date().toISOString() });
  saveConversation(conv);
  return conv;
}

function listConversations() {
  const dir = conversationsDir();
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.json'));
  return files
    .map((f) => readJSON(path.join(dir, f), null))
    .filter(Boolean)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

module.exports = {
  startConversation,
  loadConversation,
  saveConversation,
  appendMessage,
  listConversations,
};
