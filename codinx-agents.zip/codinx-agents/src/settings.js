'use strict';

const readline = require('readline');
const { C } = require('./banner');
const perms = require('./permissions');
const { MODELS, listByTier, providerOf } = require('./models');
const { getUser, saveUser } = require('./auth');

function printHeader(title) {
  process.stdout.write('\n' + C.fg.brightCyan + C.bold + '  CodinX — ' + title + '\n' + C.reset);
  process.stdout.write(C.fg.gray + '  ' + '─'.repeat(48) + C.reset + '\n\n');
}

// Show available slash commands
function showHelp() {
  printHeader('Help');
  const cmds = [
    ['/help',          'Tampilkan bantuan ini'],
    ['/models',        'Lihat semua model tersedia'],
    ['/model <id>',    'Pilih model aktif'],
    ['/tier <FREE|PRO|MAX>', 'Ubah tier Anda (memengaruhi akses model & Dinar)'],
    ['/settings',      'Buka menu permission tool'],
    ['/memory',        'Lihat percakapan tersimpan'],
    ['/new',           'Mulai percakapan baru'],
    ['/dinar',         'Lihat sisa Dinar / status tier'],
    ['/web',           'Buka web UI di http://localhost:3000'],
    ['/clear',         'Bersihkan layar'],
    ['/quit',          'Keluar dari CodinX'],
  ];
  for (const [c, d] of cmds) {
    process.stdout.write('  ' + C.fg.brightYellow + c.padEnd(22) + C.reset + ' ' + d + '\n');
  }
  process.stdout.write('\n');
}

// List all models grouped by provider
function showModels() {
  printHeader('Models (' + MODELS.length + ')');
  const byProvider = {};
  for (const m of MODELS) {
    const p = providerOf(m);
    if (!byProvider[p]) byProvider[p] = [];
    byProvider[p].push(m);
  }
  const tierColor = (t) =>
    t === 'MAX' ? C.fg.brightMagenta :
    t === 'PRO' ? C.fg.brightCyan :
    C.fg.brightGreen;
  for (const [prov, list] of Object.entries(byProvider)) {
    process.stdout.write('  ' + C.bold + C.fg.brightBlue + prov + C.reset + '\n');
    for (const m of list) {
      const badge = tierColor(m.tier) + '[' + m.tier.padEnd(4) + ']' + C.reset;
      const price = m.pricing ? C.fg.gray + ' (' + m.pricing + ')' + C.reset : '';
      const trial = m.trial ? C.fg.brightYellow + ' (trial: ' + m.trial.requests + 'x)' + C.reset : '';
      process.stdout.write('     ' + badge + ' ' + m.id.padEnd(34) + ' ' + m.name + price + trial + '\n');
    }
    process.stdout.write('\n');
  }
}

function selectModel(rl) {
  return new Promise((resolve) => {
    printHeader('Select Model');
    showModels();
    process.stdout.write(C.fg.brightYellow + '  Masukkan model id: ' + C.reset);
    rl.question('', (answer) => {
      const id = (answer || '').trim();
      resolve(id);
    });
  });
}

// Settings menu (permission toggles + tier upgrade)
function openSettings(rl) {
  return new Promise((resolve) => {
    const loop = () => {
      perms.showSettings();
      const user = getUser();
      process.stdout.write(C.fg.brightCyan + '  Tier Anda: ' + C.reset + user.tier + '\n');
      process.stdout.write(C.fg.gray + '  Pilih tool untuk toggle (allow/ask/deny), atau ketik /back\n' + C.reset);
      process.stdout.write('  > ');
      rl.question('', (answer) => {
        const a = (answer || '').trim();
        if (a === '/back' || a === 'exit' || a === 'quit' || a === '') return resolve();
        const parts = a.split(/\s+/);
        const toolKey = parts[0];
        const state = parts[1];
        if (toolKey === 'reset') {
          perms.resetAll();
          process.stdout.write(C.fg.brightGreen + '  Permissions reset.\n' + C.reset);
          return loop();
        }
        if (toolKey === 'tier') {
          const newTier = (state || '').toUpperCase();
          if (['FREE', 'PRO', 'MAX'].includes(newTier)) {
            user.tier = newTier;
            saveUser(user);
            process.stdout.write(C.fg.brightGreen + '  Tier updated to ' + newTier + '\n' + C.reset);
          } else {
            process.stdout.write(C.fg.brightRed + '  Tier tidak valid.\n' + C.reset);
          }
          return loop();
        }
        const valid = ['allow', 'ask', 'deny'].includes(state);
        if (!valid) {
          process.stdout.write(C.fg.brightRed + '  Format: <toolKey> <allow|ask|deny>\n' + C.reset);
          return loop();
        }
        if (!perms.TOOL_KEYS.includes(toolKey)) {
          process.stdout.write(C.fg.brightRed + '  Tool key tidak dikenal: ' + toolKey + '\n' + C.reset);
          return loop();
        }
        perms.setPermission(toolKey, state);
        process.stdout.write(C.fg.brightGreen + '  ' + toolKey + ' -> ' + state + '\n' + C.reset);
        loop();
      });
    };
    loop();
  });
}

module.exports = { printHeader, showHelp, showModels, selectModel, openSettings };
