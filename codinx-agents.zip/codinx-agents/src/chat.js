'use strict';

const readline = require('readline');
const { C, printBanner } = require('./banner');
const { checkRootLocal, promptProvince, getUser, ensureDataDir } = require('./auth');
const { MODELS, findById, tzForProvince } = require('./models');
const { streamChat } = require('./api');
const { startConversation, loadConversation, saveConversation, appendMessage, listConversations } = require('./memory');
const dinar = require('./dinar');
const perms = require('./permissions');
const { parseToolCalls, runToolCall } = require('./tools');
const { renderMarkdown } = require('./tools/markdown');
const { showHelp, showModels, selectModel, openSettings, printHeader } = require('./settings');
const { startServer } = require('./web/server');

let currentConv = null;
let currentModel = 'glm-4.5-flash';
let webServerStarted = false;

function clearScreen() {
  process.stdout.write('\x1b[2J\x1b[H');
}

function printPrompt() {
  const user = getUser();
  const tier = user.tier || 'FREE';
  const tierColor = tier === 'MAX' ? C.fg.brightMagenta : tier === 'PRO' ? C.fg.brightCyan : C.fg.brightGreen;
  const din = user.tier === 'FREE' ? ` | Dinar ${user.dinar ?? 0}/1300` : '';
  const conv = currentConv ? ` | conv:${currentConv.id.slice(-6)}` : '';
  process.stdout.write(
    '\n' + tierColor + C.bold + ` [${tier}]` + C.reset +
    C.fg.brightBlue + ` ${currentModel}` + C.reset +
    C.fg.gray + `${din}${conv}` + C.reset +
    '\n' + C.fg.brightYellow + ' ❯ ' + C.reset
  );
}

async function handleStream(model, messages, conv) {
  let full = '';
  process.stdout.write(C.fg.white);
  try {
    await streamChat({
      model,
      messages,
      conversationId: conv.id,
      onToken: (t) => {
        process.stdout.write(t);
        full += t;
      },
    });
    process.stdout.write(C.reset + '\n');
  } catch (e) {
    process.stdout.write(C.reset + '\n');
    process.stdout.write(C.fg.brightRed + '  [stream error] ' + e.message + '\n' + C.reset);
    if (!full) {
      throw e;
    }
  }
  return full;
}

async function handleUserInput(rl, input) {
  const text = input.trim();
  if (!text) {
    printPrompt();
    return;
  }

  if (text.startsWith('/')) {
    const [cmd, ...rest] = text.slice(1).split(/\s+/);
    switch (cmd) {
      case 'help':
        showHelp();
        break;
      case 'models':
        showModels();
        break;
      case 'model':
        if (rest[0]) {
          const m = findById(rest[0]);
          if (m) {
            currentModel = m.id;
            process.stdout.write(C.fg.brightGreen + '  Model aktif: ' + m.name + ' (' + m.id + ')\n' + C.reset);
          } else {
            process.stdout.write(C.fg.brightRed + '  Model tidak ditemukan: ' + rest[0] + '\n' + C.reset);
          }
        } else {
          const id = await selectModel(rl);
          const m = findById(id);
          if (m) {
            currentModel = m.id;
            process.stdout.write(C.fg.brightGreen + '  Model aktif: ' + m.name + '\n' + C.reset);
          }
        }
        break;
      case 'tier': {
        const t = (rest[0] || '').toUpperCase();
        if (!['FREE', 'PRO', 'MAX'].includes(t)) {
          process.stdout.write(C.fg.brightRed + '  Tier tidak valid. Pakai: /tier FREE|PRO|MAX\n' + C.reset);
          break;
        }
        const user = getUser();
        user.tier = t;
        if (t === 'FREE') user.dinar = dinar.DAILY_DINAR_FREE;
        require('./auth').saveUser(user);
        process.stdout.write(C.fg.brightGreen + '  Tier diubah ke ' + t + '\n' + C.reset);
        break;
      }
      case 'settings':
        await openSettings(rl);
        break;
      case 'memory': {
        const convs = listConversations();
        printHeader('Conversations (' + convs.length + ')');
        for (const c of convs.slice(0, 10)) {
          process.stdout.write('  ' + C.fg.brightCyan + c.id + C.reset + '  ' + c.model + '  ' + c.createdAt + '\n');
        }
        break;
      }
      case 'new': {
        const user = getUser();
        currentConv = startConversation(currentModel, user.province);
        process.stdout.write(C.fg.brightGreen + '  Percakapan baru dimulai: ' + currentConv.id + '\n' + C.reset);
        break;
      }
      case 'dinar': {
        const user = dinar.resetIfNeeded(getUser());
        process.stdout.write(C.fg.brightYellow + '  ' + dinar.statusString(user) + '\n' + C.reset);
        break;
      }
      case 'web': {
        if (!webServerStarted) {
          startServer();
          webServerStarted = true;
        } else {
          process.stdout.write(C.fg.brightGreen + '  Web UI sudah berjalan di http://localhost:3000\n' + C.reset);
        }
        break;
      }
      case 'clear':
        clearScreen();
        break;
      case 'quit':
      case 'exit':
        process.stdout.write(C.fg.brightCyan + '  Sampai jumpa! CodinX out.\n' + C.reset);
        process.exit(0);
      default:
        process.stdout.write(C.fg.brightRed + '  Command tidak dikenal: /' + cmd + '\n' + C.reset);
        showHelp();
    }
    printPrompt();
    return;
  }

  // Start a conversation if not yet
  if (!currentConv) {
    const user = getUser();
    currentConv = startConversation(currentModel, user.province);
    process.stdout.write(C.fg.gray + '  (percakapan baru: ' + currentConv.id + ')\n' + C.reset);
  }

  // Reset dinar if needed, then check spend
  let user = dinar.resetIfNeeded(getUser());
  const can = dinar.canSpend(user);
  if (!can.ok) {
    process.stdout.write(
      C.fg.brightRed + '  Dinar habis (' + can.dinar + '/' + dinar.DINAR_PER_REQUEST + ' dibutuhkan). Reset besok midnight (tz: ' +
      tzForProvince(user.province) + ').\n' + C.reset
    );
    printPrompt();
    return;
  }

  // Append user message
  appendMessage(currentConv, 'user', text);

  // Stream response
  try {
    const reply = await handleStream(currentModel, currentConv.messages, currentConv);

    // Append assistant reply
    appendMessage(currentConv, 'assistant', reply);

    // Render markdown for nicer output
    process.stdout.write('\n' + renderMarkdown(reply) + '\n');

    // Detect tool calls
    const calls = parseToolCalls(reply);
    if (calls.length) {
      for (const call of calls) {
        process.stdout.write(C.fg.brightMagenta + '\n  ⚙ Tool call: ' + call.tool + C.reset + '\n');
        const result = await runToolCall(call, rl);
        if (result.ok) {
          process.stdout.write(C.fg.brightGreen + '  ✓ Tool result: ' + JSON.stringify(result).slice(0, 500) + C.reset + '\n');
          // Feed the tool result back into conversation memory
          appendMessage(currentConv, 'tool', JSON.stringify({ tool: call.tool, args: call.args, result }));
        } else {
          process.stdout.write(C.fg.brightRed + '  ✗ Tool gagal: ' + (result.error || result.reason) + C.reset + '\n');
          appendMessage(currentConv, 'tool_error', JSON.stringify({ tool: call.tool, error: result.error || result.reason }));
        }
      }
      process.stdout.write(C.fg.gray + '  (lanjutkan percakapan jika perlu)\n' + C.reset);
    }

    // Charge Dinar after successful request
    user = dinar.spend(getUser());
  } catch (e) {
    process.stdout.write(C.fg.brightRed + '\n  [Error] ' + e.message + '\n' + C.reset);
  }

  printPrompt();
}

async function main(argv = []) {
  // 1. Auth check
  const auth = checkRootLocal();
  if (!auth.ok) {
    process.stderr.write(C.fg.brightRed + C.bold + '\n  CodinX access denied.\n' + C.reset);
    process.stderr.write(C.fg.brightRed + '  ' + auth.reason + '\n' + C.reset);
    process.stderr.write(C.fg.gray + '  Hanya user "root@localhost" (atau root@<lainnya>) yang boleh menjalankan CodinX.\n\n' + C.reset);
    process.exit(1);
  }

  ensureDataDir();

  // 2. Banner
  printBanner();
  process.stdout.write(C.fg.gray + '  Logged in as: ' + C.reset + C.fg.brightGreen + auth.user + '@' + auth.hostname + C.reset + '\n');

  // 3. Web-only mode: skip prompts, just start server
  if (argv.includes('--web-only')) {
    let u = getUser();
    if (!u || !u.province) {
      // seed default province for web-only mode
      const { saveUser } = require('./auth');
      saveUser({ province: 'default', tier: 'FREE', createdAt: new Date().toISOString(), requestsToday: 0, dinar: 1300, lastReset: new Date().toISOString(), lastResetDate: '' });
    }
    dinar.resetIfNeeded(getUser());
    startServer();
    return;
  }

  // 4. Province prompt (first run, interactive only)
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: true,
    prompt: '',
  });

  await promptProvince(rl);

  // 5. Reset dinar for new day if needed
  let user = getUser();
  user = dinar.resetIfNeeded(user);

  // 6. Show initial help
  showHelp();

  // 7. Chat loop
  printPrompt();
  rl.on('line', async (line) => {
    try {
      await handleUserInput(rl, line);
    } catch (e) {
      process.stdout.write(C.fg.brightRed + '\n  [unexpected error] ' + e.message + '\n' + C.reset);
      printPrompt();
    }
  });
  rl.on('SIGINT', () => {
    process.stdout.write('\n' + C.fg.brightCyan + '  Sampai jumpa! CodinX out.\n' + C.reset);
    process.exit(0);
  });
  rl.on('SIGTSTP', () => {
    process.stdout.write('\n' + C.fg.gray + '  Use /quit to exit.\n' + C.reset);
    printPrompt();
  });
}

module.exports = { main, handleUserInput, printPrompt };

if (require.main === module) {
  main(process.argv.slice(2));
}
