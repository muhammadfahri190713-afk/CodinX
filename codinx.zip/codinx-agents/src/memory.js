'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { ensureDataDir, readJSON, writeJSON } = require('./auth');
const { tzForProvince } = require('./models');

// Conversation memory store.
// Mechanism: each conversation has a stable conversation_id that gets sent as metadata
// to the API so the backend keeps one thread per conversation (less forgetting).

function conversationsDir() {
  const dir = path.join(__dirname, '..', 'data', 'conversations');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function newConversationId() {
  return 'cx_' + crypto.randomBytes(12).toString('hex');
}

function startConversation(model, province) {
  const dir = conversationsDir();
  const id = newConversationId();
  const conv = {
    id,
    model,
    province: province || 'default',
    tz: tzForProvince(province),
    createdAt: new Date().toISOString(),
    messages: [
      {
        role: 'system',
        content: [
          'You are CodinX, a powerful terminal-based AI agent (inspired by Claude Code, Codex, OpenCode).',
          '',
          'CAPABILITIES — you have these tools (skills) available:',
          '  1. file.create   — Create or overwrite a file.  args: {"path":"<abs>","content":"<text>"}',
          '  2. file.read     — Read a file.                 args: {"path":"<abs>"}',
          '  3. table         — Render a table.              args: {"headers":[...],"rows":[[...]],"format":"ascii|markdown|csv"}',
          '  4. web.fetch     — HTTP GET a URL.              args: {"url":"<url>"}',
          '  5. shell.exec    — Run a shell command.         args: {"cmd":"<command>"}',
          '',
          'TOOL INVOCATION FORMAT (very important):',
          'When you want to run a tool, output this exact block on its own line:',
          '  <<<TOOL:toolname>>>{...json args...}<<<END>>>',
          'Examples:',
          '  <<<TOOL:file.create>>>{"path":"/tmp/hello.txt","content":"Hello from CodinX"}<<<END>>>',
          '  <<<TOOL:shell.exec>>>{"cmd":"ls -la /tmp"}<<<END>>>',
          '  <<<TOOL:table>>>{"headers":["Name","Age"],"rows":[["Alice","30"],["Bob","25"]],"format":"ascii"}<<<END>>>',
          '  <<<TOOL:web.fetch>>>{"url":"https://example.com"}<<<END>>>',
          '',
          'BEHAVIOR RULES:',
          '- Be proactive: when the user asks you to create a file, run a command, or fetch data, USE THE TOOL — do not just describe it.',
          '- Always explain briefly what you are about to do before invoking the tool.',
          '- After a tool runs, summarize the result for the user in markdown.',
          '- Use markdown formatting (headings, bold, lists, tables, code blocks) to make output readable.',
          '- Be concise but complete. Never produce single-sentence answers when the user asks for something complex.',
          '- If a tool might be sensitive (shell.exec, file.write), warn the user before invoking.',
          '- You may chain multiple tool calls in a single reply if logically needed.',
          '',
          'You are running on the user\'s terminal as root@localhost. Be helpful, smart, and cautious.',
        ].join('\n'),
      },
    ],
  };
  writeJSON(path.join(dir, id + '.json'), conv);
  return conv;
}

function loadConversation(id) {
  const file = path.join(conversationsDir(), id + '.json');
  return readJSON(file, null);
}

function saveConversation(conv) {
  const file = path.join(conversationsDir(), conv.id + '.json');
  writeJSON(file, conv);
}

function appendMessage(conv, role, content) {
  conv.messages.push({ role, content, ts: new Date().toISOString() });
  saveConversation(conv);
  return conv;
}

function listConversations() {
  const dir = conversationsDir();
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.json'));
  return files
    .map((f) => readJSON(path.join(dir, f), null))
    .filter(Boolean)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

module.exports = {
  startConversation,
  loadConversation,
  saveConversation,
  appendMessage,
  listConversations,
};
