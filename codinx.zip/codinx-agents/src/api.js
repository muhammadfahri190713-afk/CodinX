'use strict';

const https = require('https');
const http = require('http');
const { URL } = require('url');

const ENDPOINT = 'https://inttelix.vercel.app/api/v1';
const API_KEY = 'sk-itlx-983afa2af56d48b230d728c984de3162bd42d3e97d9dcff6d4f001373e605cedf3801a959040ea35';

function request(method, pathStr, body) {
  return new Promise((resolve, reject) => {
    const url = new URL(ENDPOINT + pathStr);
    const lib = url.protocol === 'https:' ? https : http;
    const payload = body ? JSON.stringify(body) : null;
    const headers = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
      'User-Agent': 'CodinX/1.0.0',
    };
    if (payload) headers['Content-Length'] = Buffer.byteLength(payload);

    const req = lib.request(
      {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname + (url.search || ''),
        method,
        headers,
      },
      (res) => {
        let chunks = '';
        res.on('data', (d) => {
          chunks += d;
        });
        res.on('end', () => {
          let parsed = null;
          try {
            parsed = JSON.parse(chunks);
          } catch {
            parsed = chunks;
          }
          resolve({ status: res.statusCode, headers: res.headers, body: parsed });
        });
      }
    );

    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// Streaming chat completion via SSE
function streamChat({ model, messages, conversationId, onToken, onDone, onError, signal }) {
  return new Promise((resolve, reject) => {
    const url = new URL(ENDPOINT + '/chat/completions');
    const lib = url.protocol === 'https:' ? https : http;
    const body = JSON.stringify({
      model,
      messages,
      stream: true,
      metadata: { conversation_id: conversationId },
    });
    const req = lib.request(
      {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${API_KEY}`,
          'User-Agent': 'CodinX/1.0.0',
          'Content-Length': Buffer.byteLength(body),
        },
      },
      (res) => {
        if (res.statusCode !== 200) {
          let buf = '';
          res.on('data', (c) => (buf += c));
          res.on('end', () => {
            const err = new Error(`HTTP ${res.statusCode}: ${buf}`);
            if (onError) onError(err);
            return reject(err);
          });
          return;
        }
        let buffer = '';
        res.on('data', (chunk) => {
          buffer += chunk.toString();
          const lines = buffer.split('\n');
          buffer = lines.pop();
          for (const raw of lines) {
            const line = raw.trim();
            if (!line) continue;
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              if (data === '[DONE]') {
                if (onDone) onDone();
                return resolve();
              }
              try {
                const json = JSON.parse(data);
                const delta = json.choices && json.choices[0] && json.choices[0].delta;
                if (delta && delta.content) {
                  if (onToken) onToken(delta.content, json);
                }
              } catch {
                /* ignore non-JSON keepalives */
              }
            }
          }
        });
        res.on('end', () => {
          if (onDone) onDone();
          resolve();
        });
        res.on('error', (e) => {
          if (onError) onError(e);
          reject(e);
        });
      }
    );
    req.on('error', (e) => {
      if (onError) onError(e);
      reject(e);
    });
    if (signal) {
      signal.addEventListener('abort', () => req.destroy());
    }
    req.write(body);
    req.end();
  });
}

// Non-streaming chat completion (for fallback)
async function chat({ model, messages, conversationId }) {
  const res = await request('POST', '/chat/completions', {
    model,
    messages,
    metadata: { conversation_id: conversationId },
  });
  return res.body;
}

// List models from endpoint
async function listModels() {
  const res = await request('GET', '/models');
  return res.body;
}

module.exports = { request, streamChat, chat, listModels, ENDPOINT, API_KEY };
