'use strict';

const { getUser, saveUser } = require('./auth');
const { tzForProvince } = require('./models');
const { C } = require('./banner');

// Dinar system:
//   FREE: 1300 Dinar/day. 65 Dinar = 1 request.
//   Reset happens at local midnight (timezone determined by user's province).
//   PRO: unlimited requests but tracked. MAX: unlimited, premium.

const DAILY_DINAR_FREE = 1300;
const DINAR_PER_REQUEST = 65;

function _now(tz) {
  // Format YYYY-MM-DD in given timezone using Intl
  if (!tz) tz = 'Asia/Jakarta';
  const opts = { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' };
  const parts = new Intl.DateTimeFormat('en-CA', opts).formatToParts(new Date());
  const y = parts.find((p) => p.type === 'year').value;
  const m = parts.find((p) => p.type === 'month').value;
  const d = parts.find((p) => p.type === 'day').value;
  return `${y}-${m}-${d}`;
}

function _msUntilMidnight(tz) {
  if (!tz) tz = 'Asia/Jakarta';
  // Get tomorrow 00:00 in tz, convert to epoch ms.
  // Compute current time in tz, then add the remaining time.
  const now = new Date();
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hour: 'numeric', minute: 'numeric', second: 'numeric',
    hour12: false, year: 'numeric', month: '2-digit', day: '2-digit',
  });
  const parts = formatter.formatToParts(now);
  const p = (t) => parts.find((x) => x.type === t).value;
  const tzNow = new Date(`${p('year')}-${p('month')}-${p('day')}T${p('hour')}:${p('minute')}:${p('second')}`);
  // tzNow is the current local time string; we need ms until next 00:00
  const msIntoDay = (Number(p('hour')) * 3600 + Number(p('minute')) * 60 + Number(p('second'))) * 1000;
  const msInDay = 86400000;
  return msInDay - msIntoDay;
}

function resetIfNeeded(user) {
  const tz = tzForProvince(user.province);
  const today = _now(tz);
  if (user.lastResetDate !== today) {
    user.lastResetDate = today;
    user.requestsToday = 0;
    if (user.tier === 'FREE') user.dinar = DAILY_DINAR_FREE;
    saveUser(user);
    process.stdout.write(
      C.fg.brightGreen + `\n  [Dinar] Reset harian selesai (${tz}). Dinar ${user.tier === 'FREE' ? user.dinar : '∞'}\n` + C.reset
    );
  }
  return user;
}

function canSpend(user) {
  if (user.tier === 'PRO' || user.tier === 'MAX') return { ok: true, dinar: Infinity };
  if (user.dinar >= DINAR_PER_REQUEST) return { ok: true, dinar: user.dinar };
  return { ok: false, dinar: user.dinar, need: DINAR_PER_REQUEST };
}

function spend(user, amount = DINAR_PER_REQUEST) {
  user.requestsToday = (user.requestsToday || 0) + 1;
  if (user.tier === 'FREE') {
    user.dinar = Math.max(0, (user.dinar || 0) - amount);
  }
  saveUser(user);
  return user;
}

function statusString(user) {
  const tz = tzForProvince(user.province);
  const ms = _msUntilMidnight(tz);
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const remain = `${h}h ${m}m ${s}s`;
  if (user.tier === 'FREE') {
    const requestsLeft = Math.floor(user.dinar / DINAR_PER_REQUEST);
    return `Tier: FREE | Dinar: ${user.dinar}/${DAILY_DINAR_FREE} | ≈${requestsLeft} request tersisa | Reset dalam ${remain} (${tz})`;
  }
  return `Tier: ${user.tier} | Requests hari ini: ${user.requestsToday || 0} | Unlimited`;
}

module.exports = {
  DAILY_DINAR_FREE,
  DINAR_PER_REQUEST,
  resetIfNeeded,
  canSpend,
  spend,
  statusString,
};
