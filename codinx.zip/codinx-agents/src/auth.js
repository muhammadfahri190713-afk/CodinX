'use strict';

const os = require('os');
const fs = require('fs');
const path = require('path');
const { C } = require('./banner');

// CodinX only runs when current OS user is "root" and host is "localhost" (or any root@*)
function checkRootLocal() {
  const userInfo = os.userInfo();
  const hostname = os.hostname();
  const user = userInfo.username;

  const isRoot = user === 'root';
  const isLocalhost =
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname.startsWith('localhost') ||
    hostname.endsWith('.local') ||
    hostname.endsWith('.localhost');

  // Allow root@<anything> per spec ("root@localhost" atau "root@" lainnya bisa)
  if (isRoot) {
    return { ok: true, user, hostname };
  }
  return {
    ok: false,
    user,
    hostname,
    reason: `CodinX hanya boleh dijalankan oleh user "root" (saat ini: "${user}"). Host: "${hostname}".`,
  };
}

function ensureDataDir() {
  const dataDir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(path.join(dataDir, 'conversations'))) {
    fs.mkdirSync(path.join(dataDir, 'conversations'), { recursive: true });
  }
  return dataDir;
}

function readJSON(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJSON(file, obj) {
  fs.writeFileSync(file, JSON.stringify(obj, null, 2));
}

// Province/timezone prompt for first run
function promptProvince(rl) {
  return new Promise((resolve) => {
    const userFile = path.join(__dirname, '..', 'data', 'user.json');
    ensureDataDir();
    const existing = readJSON(userFile, null);
    if (existing && existing.province) {
      return resolve(existing);
    }
    process.stdout.write(
      C.fg.brightCyan +
        '\n  CodinX: Sebelum mulai, masukkan provinsi Anda (untuk reset Dinar tepat waktu):\n  > ' +
        C.reset
    );
    rl.question('', (answer) => {
      const province = (answer || '').trim() || 'default';
      const obj = {
        province,
        tier: 'FREE',
        createdAt: new Date().toISOString(),
        requestsToday: 0,
        dinar: 1300,
        lastReset: new Date().toISOString(),
      };
      writeJSON(userFile, obj);
      resolve(obj);
    });
  });
}

function getUser() {
  const userFile = path.join(__dirname, '..', 'data', 'user.json');
  return readJSON(userFile, { province: 'default', tier: 'FREE', dinar: 1300, requestsToday: 0 });
}

function saveUser(user) {
  const userFile = path.join(__dirname, '..', 'data', 'user.json');
  writeJSON(userFile, user);
}

module.exports = {
  checkRootLocal,
  ensureDataDir,
  readJSON,
  writeJSON,
  promptProvince,
  getUser,
  saveUser,
};
