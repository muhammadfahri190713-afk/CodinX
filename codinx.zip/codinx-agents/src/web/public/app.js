'use strict';

const $ = (sel) => document.querySelector(sel);

async function api(path, opts) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  return res.json();
}

function stateBadge(state) {
  const map = { allow: 'ALLOW', ask: 'ASK', deny: 'DENY' };
  return map[state] || 'ASK';
}

async function loadSettings() {
  const data = await api('/api/settings');
  const list = $('#permsList');
  list.innerHTML = '';
  for (const tool of data.tools) {
    const state = data.settings[tool] || 'ask';
    const row = document.createElement('div');
    row.className = 'perm-row';
    row.innerHTML = `
      <div class="perm-key">${tool}</div>
      <div class="perm-actions">
        ${['allow','ask','deny'].map(s => `
          <button class="perm-btn ${state===s?'active':''}" data-state="${s}" data-tool="${tool}">${stateBadge(s)}</button>
        `).join('')}
      </div>
    `;
    list.appendChild(row);
  }
  list.querySelectorAll('.perm-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const tool = btn.dataset.tool;
      const state = btn.dataset.state;
      await api('/api/settings', {
        method: 'POST',
        body: JSON.stringify({ toolKey: tool, state }),
      });
      await loadSettings();
    });
  });

  $('#tierSelect').value = data.user.tier || 'FREE';
}

async function loadStatus() {
  const data = await api('/api/status');
  $('#statusBar').textContent = data.status;
  $('#dinarVal').textContent = data.user.tier === 'FREE' ? (data.user.dinar ?? 0) + ' / 1300' : '∞';
  $('#reqVal').textContent = data.user.requestsToday ?? 0;
  $('#resetVal').textContent = data.user.lastResetDate || '-';
}

async function loadModels(filter = '') {
  const data = await api('/api/models');
  const list = $('#modelsList');
  list.innerHTML = '';
  const f = filter.toLowerCase();
  const filtered = data.models.filter(m =>
    m.id.toLowerCase().includes(f) ||
    m.name.toLowerCase().includes(f) ||
    (m.tier || '').toLowerCase().includes(f)
  );
  for (const m of filtered) {
    const item = document.createElement('div');
    item.className = 'model-item';
    item.innerHTML = `
      <span class="badge ${m.tier}">${m.tier}</span>
      <span class="model-name">${m.name}</span>
      <span class="model-id">${m.id}</span>
      ${m.pricing ? `<span class="model-id">💰 ${m.pricing}</span>` : ''}
      ${m.trial ? `<span class="model-id">🧪 trial: ${m.trial.requests}x</span>` : ''}
    `;
    list.appendChild(item);
  }
}

$('#tierSelect').addEventListener('change', async (e) => {
  await api('/api/user/tier', {
    method: 'POST',
    body: JSON.stringify({ tier: e.target.value }),
  });
  await loadStatus();
});

$('#resetBtn').addEventListener('click', async () => {
  if (!confirm('Reset semua permission ke ASK?')) return;
  await api('/api/settings/reset', { method: 'POST' });
  await loadSettings();
});

$('#modelSearch').addEventListener('input', (e) => loadModels(e.target.value));

(async function init() {
  await loadSettings();
  await loadStatus();
  await loadModels();
  setInterval(loadStatus, 5000);
})();
