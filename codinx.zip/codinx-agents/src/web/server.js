'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { C } = require('../banner');
const perms = require('../permissions');
const { getUser, saveUser } = require('../auth');
const { MODELS } = require('../models');
const dinar = require('../dinar');

const PORT = 3000;

function serveFile(req, res, filePath, contentType) {
  try {
    const data = fs.readFileSync(filePath);
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  } catch {
    res.writeHead(404);
    res.end('Not Found');
  }
}

function sendJSON(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
}

function readBody(req) {
  return new Promise((resolve) => {
    let chunks = '';
    req.on('data', (c) => (chunks += c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(chunks || '{}'));
      } catch {
        resolve({});
      }
    });
  });
}

function startServer() {
  const publicDir = path.join(__dirname, 'public');

  const server = http.createServer(async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }

    const url = new URL(req.url, `http://localhost:${PORT}`);

    // ---- static files ----
    if (url.pathname === '/' || url.pathname === '/index.html') {
      return serveFile(req, res, path.join(publicDir, 'index.html'), 'text/html; charset=utf-8');
    }
    if (url.pathname === '/style.css') {
      return serveFile(req, res, path.join(publicDir, 'style.css'), 'text/css; charset=utf-8');
    }
    if (url.pathname === '/app.js') {
      return serveFile(req, res, path.join(publicDir, 'app.js'), 'application/javascript; charset=utf-8');
    }

    // ---- API: settings ----
    if (url.pathname === '/api/settings' && req.method === 'GET') {
      return sendJSON(res, 200, { settings: perms.loadSettings(), tools: perms.TOOL_KEYS, user: getUser(), models: MODELS });
    }
    if (url.pathname === '/api/settings' && req.method === 'POST') {
      const body = await readBody(req);
      const { toolKey, state } = body;
      if (!perms.TOOL_KEYS.includes(toolKey)) return sendJSON(res, 400, { error: 'invalid tool' });
      if (!['allow', 'ask', 'deny'].includes(state)) return sendJSON(res, 400, { error: 'invalid state' });
      perms.setPermission(toolKey, state);
      return sendJSON(res, 200, { ok: true, settings: perms.loadSettings() });
    }
    if (url.pathname === '/api/settings/reset' && req.method === 'POST') {
      perms.resetAll();
      return sendJSON(res, 200, { ok: true });
    }

    // ---- API: user / dinar ----
    if (url.pathname === '/api/user' && req.method === 'GET') {
      const user = dinar.resetIfNeeded(getUser());
      return sendJSON(res, 200, { user, status: dinar.statusString(user) });
    }
    if (url.pathname === '/api/user/tier' && req.method === 'POST') {
      const body = await readBody(req);
      const t = (body.tier || '').toUpperCase();
      if (!['FREE', 'PRO', 'MAX'].includes(t)) return sendJSON(res, 400, { error: 'invalid tier' });
      const user = getUser();
      user.tier = t;
      saveUser(user);
      return sendJSON(res, 200, { ok: true, user });
    }

    // ---- API: models ----
    if (url.pathname === '/api/models' && req.method === 'GET') {
      return sendJSON(res, 200, { models: MODELS });
    }

    // ---- API: status ----
    if (url.pathname === '/api/status' && req.method === 'GET') {
      const user = dinar.resetIfNeeded(getUser());
      return sendJSON(res, 200, { user, status: dinar.statusString(user), perms: perms.loadSettings() });
    }

    res.writeHead(404);
    res.end('Not Found');
  });

  server.listen(PORT, '127.0.0.1', () => {
    process.stdout.write(
      C.fg.brightGreen + C.bold +
      `\n  CodinX Web UI: http://localhost:${PORT}\n` +
      C.reset + C.fg.gray +
      '  Tekan Ctrl+C untuk berhenti.\n\n' + C.reset
    );
  });

  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      process.stdout.write(C.fg.brightRed + `\n  Port ${PORT} sedang dipakai. CodinX web UI tidak bisa start.\n` + C.reset);
    } else {
      process.stdout.write(C.fg.brightRed + `\n  Web server error: ${e.message}\n` + C.reset);
    }
  });

  return server;
}

module.exports = { startServer, PORT };
