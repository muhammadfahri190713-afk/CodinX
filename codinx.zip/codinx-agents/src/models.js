'use strict';

// Full model catalog for CodinX.
// Each model has: id (code name), name (display), tier (FREE|PRO|MAX), optional pricing, optional trial flag.

const MODELS = [
  // ============== CLAUDE (Anthropic) ==============
  { id: 'claude-fable-5',     name: 'Claude Fable 5',        tier: 'MAX'  },
  { id: 'claude-fable-5.1',   name: 'Claude Fable 5.1',      tier: 'MAX'  },
  { id: 'claude-haiku-4.5',   name: 'Claude Haiku 4.5',      tier: 'PRO', trial: { requests: 3 } },
  { id: 'claude-opus-4.5',    name: 'Claude Opus 4.5',        tier: 'PRO'  },
  { id: 'claude-opus-4.6',    name: 'Claude Opus 4.6',        tier: 'PRO'  },
  { id: 'claude-opus-4.7',    name: 'Claude Opus 4.7',        tier: 'PRO'  },
  { id: 'claude-opus-4.8',    name: 'Claude Opus 4.8',        tier: 'MAX'  },
  { id: 'claude-opus-5',      name: 'Claude Opus 5',          tier: 'MAX', pricing: '$5 / $25' },
  { id: 'claude-opus-5.5',    name: 'Claude Opus 5.5',        tier: 'MAX'  },

  // Claude Sonnet family
  { id: 'claude-sonnet-4',    name: 'Claude Sonnet 4',        tier: 'PRO'  },
  { id: 'claude-sonnet-4.5',  name: 'Claude Sonnet 4.5',      tier: 'PRO'  },
  { id: 'claude-sonnet-4.6',  name: 'Claude Sonnet 4.6',      tier: 'PRO'  },
  { id: 'claude-sonnet-5',    name: 'Claude Sonnet 5',        tier: 'PRO'  },

  // ============== GPT (OpenAI) ==============
  { id: 'gpt-3.5',            name: 'GPT 3.5',               tier: 'FREE' },
  { id: 'gpt-4.1',            name: 'GPT 4.1',               tier: 'PRO'  },
  { id: 'gpt-4.1-mini',       name: 'GPT 4.1 Mini',          tier: 'FREE' },
  { id: 'gpt-4o',             name: 'GPT 4O',                tier: 'FREE' },
  { id: 'gpt-5',              name: 'GPT 5',                 tier: 'PRO', pricing: '$1.25 / $10' },
  { id: 'gpt-5-mini',         name: 'GPT 5 Mini',            tier: 'FREE', pricing: '$0.25 / $2' },
  { id: 'gpt-5-nano',         name: 'GPT 5 Nano',            tier: 'FREE', pricing: '$0.05 / $0.40' },
  { id: 'gpt-5.2',            name: 'GPT 5.2',               tier: 'PRO'  },
  { id: 'gpt-5.4',            name: 'GPT 5.4',               tier: 'PRO'  },
  { id: 'gpt-5.4-mini',       name: 'GPT 5.4 Mini',          tier: 'FREE' },
  { id: 'gpt-5.5',            name: 'GPT 5.5',               tier: 'MAX'  },
  { id: 'gpt-5.6-luna',       name: 'GPT 5.6 Luna',          tier: 'PRO'  },
  { id: 'gpt-5.6-sol',        name: 'GPT 5.6 Sol',           tier: 'MAX'  },
  { id: 'gpt-5.6-terra',      name: 'GPT 5.6 Terra',         tier: 'PRO'  },
  { id: 'gpt-6-astra',        name: 'GPT 6 Astra',           tier: 'MAX'  },
  { id: 'gpt-6-luna',         name: 'GPT 6 Luna',            tier: 'MAX'  },
  { id: 'gpt-6-sol',          name: 'GPT 6 Sol',             tier: 'MAX'  },
  { id: 'gpt-o3-mini',        name: 'GPT O3 Mini',           tier: 'FREE' },

  // ============== Gemini (Google) ==============
  { id: 'gemini-2.0-flash',   name: 'Gemini 2.0 Flash',      tier: 'FREE' },
  { id: 'gemini-2.5-flash',   name: 'Gemini 2.5 Flash',      tier: 'FREE' },
  { id: 'gemini-2.5-pro',     name: 'Gemini 2.5 Pro',        tier: 'PRO'  },
  { id: 'gemini-3-flash',     name: 'Gemini 3 Flash',        tier: 'FREE' },
  { id: 'gemini-3-pro',       name: 'Gemini 3 Pro',          tier: 'PRO', pricing: '$2 / $12' },
  { id: 'gemini-3.1-flash',   name: 'Gemini 3.1 Flash',      tier: 'FREE' },
  { id: 'gemini-3.1-pro',     name: 'Gemini 3.1 Pro',        tier: 'PRO'  },
  { id: 'gemini-3.5-flash',   name: 'Gemini 3.5 Flash',      tier: 'FREE' },
  { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash Lite', tier: 'FREE' },
  { id: 'gemini-3.6-flash',   name: 'Gemini 3.6 Flash',      tier: 'FREE' },
  { id: 'gemini-3.7-flash',   name: 'Gemini 3.7 Flash',      tier: 'FREE' },
  { id: 'gemini-3.8-flash',   name: 'Gemini 3.8 Flash',      tier: 'FREE' },
  { id: 'gemma-4-31b',        name: 'Gemma 4 31B',           tier: 'FREE' },

  // ============== Grok (xAI) ==============
  { id: 'grok-3-reasoner',    name: 'Grok 3 Reasoner',       tier: 'PRO'  },
  { id: 'grok-4',             name: 'Grok 4',                tier: 'PRO'  },
  { id: 'grok-4-fast',        name: 'Grok 4 Fast',           tier: 'FREE' },
  { id: 'grok-4-reasoning',   name: 'Grok 4 Reasoning',      tier: 'PRO'  },
  { id: 'grok-4.1',           name: 'Grok 4.1',              tier: 'PRO'  },
  { id: 'grok-4.1-fast',      name: 'Grok 4.1 Fast',         tier: 'FREE' },
  { id: 'grok-4.1-reasoning', name: 'Grok 4.1 Reasoning',    tier: 'PRO'  },
  { id: 'grok-4.2',           name: 'Grok 4.2',              tier: 'PRO'  },
  { id: 'grok-4.2-reasoning', name: 'Grok 4.2 Reasoning',    tier: 'PRO'  },
  { id: 'grok-4.3-pro',       name: 'Grok 4.3 Pro',          tier: 'PRO'  },
  { id: 'grok-4.3-reasoning', name: 'Grok 4.3 Reasoning',    tier: 'PRO'  },
  { id: 'grok-4.5',           name: 'Grok 4.5',              tier: 'PRO', pricing: '$2 / $6' },
  { id: 'grok-4.6',           name: 'Grok 4.6',              tier: 'PRO'  },
  { id: 'grok-4.7',           name: 'Grok 4.7',              tier: 'MAX'  },
  { id: 'grok-build-0.1',     name: 'Grok Build 0.1',        tier: 'PRO'  },

  // ============== DeepSeek ==============
  { id: 'deepseek-chat-v3.1', name: 'Deepseek Chat V3.1',    tier: 'FREE' },
  { id: 'deepseek-r1',        name: 'Deepseek R1',           tier: 'FREE' },
  { id: 'deepseek-v3',        name: 'Deepseek V3',           tier: 'FREE' },
  { id: 'deepseek-v3-0324',   name: 'Deepseek V3 0324',     tier: 'FREE' },
  { id: 'deepseek-v3.1',      name: 'Deepseek V3.1',         tier: 'FREE' },
  { id: 'deepseek-v3.2',      name: 'Deepseek V3.2',         tier: 'PRO', pricing: '$0.26-$0.287 input' },
  { id: 'deepseek-v3.2-think',name: 'Deepseek V3.2 Think',  tier: 'PRO'  },
  { id: 'deepseek-v4-flash',  name: 'Deepseek V4 Flash',    tier: 'FREE' },
  { id: 'deepseek-v4-flash-0731', name: 'Deepseek V4 Flash 0731', tier: 'PRO', trial: { requests: 1 } },
  { id: 'deepseek-v4-flash-vision-exp', name: 'Deepseek V4 Flash Vision Exp', tier: 'PRO' },
  { id: 'deepseek-v4-pro',    name: 'Deepseek V4 Pro',       tier: 'PRO'  },
  { id: 'deepseek-v4-pro-0813', name: 'Deepseek V4 Pro 0813', tier: 'PRO' },
  { id: 'deepseek-v4.1-flash',name: 'Deepseek V4.1 Flash',   tier: 'FREE' },

  // ============== Qwen (Alibaba) ==============
  { id: 'qwen-plus-2025-07-28', name: 'Qwen Plus 2025 07 28', tier: 'FREE' },
  { id: 'qwen3-coder-plus',   name: 'Qwen3 Coder Plus',      tier: 'PRO'  },
  { id: 'qwen3-max',          name: 'Qwen3 Max',             tier: 'PRO', pricing: '$0.86-$2.15 input' },
  { id: 'qwen3-omni-flash',   name: 'Qwen3 Omni Flash',      tier: 'FREE' },
  { id: 'qwen3-vl-plus',      name: 'Qwen3 VL Plus',         tier: 'PRO'  },
  { id: 'qwen3.5-397b-a17b',  name: 'Qwen3.5 397B A17b',     tier: 'PRO'  },
  { id: 'qwen3.5-flash',      name: 'Qwen3.5 Flash',         tier: 'FREE' },
  { id: 'qwen3.5-omni-flash', name: 'Qwen3.5 Omni Flash',    tier: 'FREE' },
  { id: 'qwen3.5-omni-plus',  name: 'Qwen3.5 Omni Plus',     tier: 'PRO'  },
  { id: 'qwen3.5-plus',       name: 'Qwen3.5 Plus',          tier: 'PRO'  },
  { id: 'qwen3.6-27b',        name: 'Qwen3.6 27B',           tier: 'FREE' },
  { id: 'qwen3.6-35b-a3b',    name: 'Qwen3.6 35B A3b',       tier: 'FREE' },
  { id: 'qwen3.6-max-preview',name: 'Qwen3.6 Max Preview',  tier: 'PRO'  },
  { id: 'qwen3.6-plus',       name: 'Qwen3.6 Plus',          tier: 'PRO'  },
  { id: 'qwen3.7-flash',      name: 'Qwen3.7 Flash',         tier: 'FREE' },
  { id: 'qwen3.7-max',        name: 'Qwen3.7 Max',           tier: 'MAX'  },
  { id: 'qwen3.7-plus',       name: 'Qwen3.7 Plus',          tier: 'PRO'  },
  { id: 'qwen3.8-max',        name: 'Qwen3.8 Max',           tier: 'MAX'  },
  { id: 'qwen3.8-omni-flash', name: 'Qwen3.8 Omni Flash',    tier: 'PRO', pricing: '$0.15 & $0.47' },

  // ============== GLM (Zhipu / Z.ai) ==============
  { id: 'glm-4.5',            name: 'GLM 4.5',               tier: 'FREE' },
  { id: 'glm-4.5-air',        name: 'GLM 4.5 Air',           tier: 'FREE' },
  { id: 'glm-4.5-airx',       name: 'GLM 4.5 AirX',         tier: 'PRO'  },
  { id: 'glm-4.5-flash',      name: 'GLM 4.5 Flash',         tier: 'FREE' },
  { id: 'glm-4.5-x',          name: 'GLM 4.5 X',             tier: 'PRO'  },
  { id: 'glm-4.5v',           name: 'GLM 4.5V',              tier: 'PRO'  },
  { id: 'glm-4.6',            name: 'GLM 4.6',               tier: 'PRO'  },
  { id: 'glm-4.6v',           name: 'GLM 4.6V',              tier: 'PRO'  },
  { id: 'glm-4.6v-flash',     name: 'GLM 4.6V Flash',        tier: 'FREE' },
  { id: 'glm-4.6v-flashx',    name: 'GLM 4.6V FlashX',       tier: 'FREE' },
  { id: 'glm-4.7',            name: 'GLM 4.7',               tier: 'PRO', pricing: '$0.43 / $1.75' },
  { id: 'glm-4.7-flash',      name: 'GLM 4.7 Flash',         tier: 'FREE', pricing: '$0.06 / $0.40' },
  { id: 'glm-4.7-flashx',     name: 'GLM 4.7 FlashX',        tier: 'FREE' },
  { id: 'glm-5',              name: 'GLM 5',                 tier: 'PRO', pricing: '$1 / $3.2' },
  { id: 'glm-5-turbo',        name: 'GLM 5 Turbo',           tier: 'PRO', pricing: '$1.20 / $4.00' },
  { id: 'glm-5.1',            name: 'GLM 5.1',               tier: 'MAX', pricing: '$1.4 / $4.4' },
  { id: 'glm-5.2',            name: 'GLM 5.2',               tier: 'MAX', pricing: '$1.4 / $4.4' },
  { id: 'glm-5.3',            name: 'GLM 5.3',               tier: 'MAX', pricing: '$1.4 / $4.4' },
  { id: 'glm-5.3-flash',      name: 'GLM 5.3 Flash',         tier: 'PRO', pricing: '$0.15 / $0.50' },
  { id: 'glm-5v-turbo',       name: 'GLM 5V Turbo',          tier: 'MAX', pricing: '$1.50 / $5.00' },

  // ============== Kimi (Moonshot) ==============
  { id: 'kimi-k2.5',          name: 'Kimi K2.5',             tier: 'FREE' },
  { id: 'kimi-k2.6',          name: 'Kimi K2.6',             tier: 'FREE' },
  { id: 'kimi-k2.7-code',     name: 'Kimi K2.7 Code',        tier: 'PRO'  },
  { id: 'kimi-k3',            name: 'Kimi K3',               tier: 'MAX'  },

  // ============== MiniMax ==============
  { id: 'minimax-m2',              name: 'MiniMax M2',              tier: 'FREE' },
  { id: 'minimax-m2.1',            name: 'MiniMax M2.1',            tier: 'FREE' },
  { id: 'minimax-m2.1-highspeed',  name: 'MiniMax M2.1 Highspeed',  tier: 'FREE' },
  { id: 'minimax-m2.5',            name: 'MiniMax M2.5',            tier: 'FREE' },
  { id: 'minimax-m2.5-highspeed',  name: 'MiniMax M2.5 Highspeed',  tier: 'FREE' },
  { id: 'minimax-m2.7',            name: 'MiniMax M2.7',            tier: 'FREE' },
  { id: 'minimax-m2.7-highspeed',  name: 'MiniMax M2.7 Highspeed',  tier: 'FREE' },
  { id: 'minimax-m3',              name: 'MiniMax M3',              tier: 'PRO'  },

  // ============== Mistral / Codestral / Ministral ==============
  { id: 'codestral-2508',      name: 'Codestral 2508',      tier: 'FREE' },
  { id: 'devstral-medium',     name: 'Devstral Medium',     tier: 'PRO'  },
  { id: 'ministral-14b',        name: 'Ministral 14B',       tier: 'FREE' },
  { id: 'ministral-3b',         name: 'Ministral 3B',        tier: 'FREE' },
  { id: 'ministral-8b',         name: 'Ministral 8B',        tier: 'FREE' },
  { id: 'mistral-large-2512',   name: 'Mistral Large 2512',  tier: 'PRO'  },
  { id: 'mistral-medium-3.5',   name: 'Mistral Medium 3.5',  tier: 'PRO'  },
  { id: 'mistral-nemo',         name: 'Mistral Nemo',         tier: 'FREE' },
  { id: 'mistral-small-2603',   name: 'Mistral Small 2603',  tier: 'FREE' },
  { id: 'mistral-small-creative', name: 'Mistral Small Creative', tier: 'FREE' },

  // ============== Cohere (Command) ==============
  { id: 'command-a',            name: 'Command A',           tier: 'PRO'  },
  { id: 'command-a-plus',        name: 'Command A Plus',      tier: 'PRO'  },
  { id: 'command-a-reasoning',  name: 'Command A Reasoning', tier: 'PRO'  },
  { id: 'command-a-translate',  name: 'Command A Translate', tier: 'FREE' },
  { id: 'command-a-vision',     name: 'Command A Vision',    tier: 'PRO'  },
  { id: 'command-r-08-2024',    name: 'Command R 08 2024',   tier: 'FREE' },
  { id: 'command-r-plus-08-2024', name: 'Command R Plus 08 2024', tier: 'PRO' },
  { id: 'command-r7b-12-2024',  name: 'Command R7b 12 2024', tier: 'FREE' },

  // ============== Doubao (ByteDance) ==============
  { id: 'doubao-1.5-pro',       name: 'Doubao 1.5 Pro',      tier: 'PRO'  },
  { id: 'doubao-seed-1.8',      name: 'Doubao Seed 1.8',     tier: 'MAX'  },
  { id: 'doubao-v3.5',          name: 'Doubao V3.5',         tier: 'PRO'  },
  { id: 'doubao-v4.2',          name: 'Doubao V4.2',         tier: 'PRO'  },
  { id: 'doubao-v4.5',          name: 'Doubao V4.5',         tier: 'MAX'  },

  // ============== Xiaomi Mimo ==============
  { id: 'mimo-v2.5',            name: 'Mimo V2.5',           tier: 'FREE' },
  { id: 'mimo-v2.5-pro',        name: 'Mimo V2.5 Pro',       tier: 'PRO'  },
  { id: 'mimo-v2.6-flash',      name: 'Mimo V2.6 Flash',     tier: 'FREE' },
  { id: 'mimo-v2.6-pro',        name: 'Mimo V2.6 Pro',       tier: 'PRO'  },

  // ============== NVIDIA Nemotron ==============
  { id: 'nemotron-3-nano-omni', name: 'Nemotron 3 Nano Omni', tier: 'FREE' },
  { id: 'nemotron-3-super',      name: 'Nemotron 3 Super',   tier: 'FREE' },
  { id: 'nemotron-3-ultra',      name: 'Nemotron 3 Ultra',   tier: 'FREE' },

  // ============== Cohere Aya ==============
  { id: 'aya-expanse-32b',      name: 'Aya Expanse 32B',     tier: 'FREE' },
  { id: 'aya-vision-32b',       name: 'Aya Vision 32B',      tier: 'FREE' },
  { id: 'tiny-aya-earth',       name: 'Tiny Aya Earth',      tier: 'FREE' },
  { id: 'tiny-aya-fire',        name: 'Tiny Aya Fire',       tier: 'FREE' },
  { id: 'tiny-aya-global',      name: 'Tiny Aya Global',     tier: 'FREE' },
  { id: 'tiny-aya-water',       name: 'Tiny Aya Water',      tier: 'FREE' },

  // ============== SenseNova ==============
  { id: 'sensenova-6.7-flash-lite', name: 'SenseNova 6.7 Flash Lite', tier: 'FREE' },
  { id: 'sensenova-6.8-flash-lite', name: 'SenseNova 6.8 Flash Lite', tier: 'FREE' },

  // ============== StepFun ==============
  { id: 'step-3.5-flash',       name: 'Step 3.5 Flash',      tier: 'FREE' },
  { id: 'step-3.5-flash-free', name: 'Step 3.5 Flash Free', tier: 'FREE' },

  // ============== Skylark ==============
  { id: 'skylark-pro',          name: 'Skylark Pro',         tier: 'PRO'  },

  // ============== Meta Llama ==============
  { id: 'llama-4',              name: 'Llama 4',             tier: 'FREE' },
  { id: 'llama-4.1',            name: 'Llama 4.1',           tier: 'PRO'  },

  // ============== Longcat ==============
  { id: 'longcat-2.0',          name: 'Longcat 2.0',         tier: 'FREE' },

  // ============== Muse / North ==============
  { id: 'muse-spark-1.2-contributor', name: 'Muse Spark 1.2 Contributor', tier: 'MAX' },
  { id: 'north-mini-code',      name: 'North Mini Code',     tier: 'FREE' },
  { id: 'north-small-translate', name: 'North Small Translate', tier: 'FREE' },
];

// Group models by provider (first word of name, before any version digit)
function providerOf(model) {
  const name = model.name;
  const m = name.match(/^([A-Za-z]+)/);
  return m ? m[1] : 'Other';
}

function listByTier(tier) {
  return MODELS.filter((m) => m.tier === tier);
}

function findById(id) {
  return MODELS.find((m) => m.id === id);
}

// Province -> IANA timezone mapping (Indonesia-focused, since user is Asia/Jakarta)
const PROVINCE_TZ = {
  // Indonesia
  'aceh': 'Asia/Jakarta',
  'sumatera utara': 'Asia/Jakarta',
  'sumatera barat': 'Asia/Jakarta',
  'riau': 'Asia/Jakarta',
  'kepulauan riau': 'Asia/Jakarta',
  'jambi': 'Asia/Jakarta',
  'sumatera selatan': 'Asia/Jakarta',
  'bangka belitung': 'Asia/Jakarta',
  'bengkulu': 'Asia/Jakarta',
  'lampung': 'Asia/Jakarta',
  'banten': 'Asia/Jakarta',
  'dki jakarta': 'Asia/Jakarta',
  'jawa barat': 'Asia/Jakarta',
  'jawa tengah': 'Asia/Jakarta',
  'di yogyakarta': 'Asia/Jakarta',
  'jawa timur': 'Asia/Jakarta',
  'bali': 'Asia/Makassar',
  'nusa tenggara barat': 'Asia/Makassar',
  'nusa tenggara timur': 'Asia/Makassar',
  'kalimantan barat': 'Asia/Pontianak',
  'kalimantan tengah': 'Asia/Pontianak',
  'kalimantan selatan': 'Asia/Makassar',
  'kalimantan timur': 'Asia/Makassar',
  'kalimantan utara': 'Asia/Makassar',
  'sulawesi utara': 'Asia/Makassar',
  'gorontalo': 'Asia/Makassar',
  'sulawesi tengah': 'Asia/Makassar',
  'sulawesi barat': 'Asia/Makassar',
  'sulawesi selatan': 'Asia/Makassar',
  'sulawesi tenggara': 'Asia/Makassar',
  'maluku': 'Asia/Jayapura',
  'maluku utara': 'Asia/Jayapura',
  'papua': 'Asia/Jayapura',
  'papua barat': 'Asia/Jayapura',
  // fallback
  'default': 'Asia/Jakarta',
};

function tzForProvince(province) {
  if (!province) return PROVINCE_TZ['default'];
  const key = province.toLowerCase().trim();
  return PROVINCE_TZ[key] || PROVINCE_TZ['default'];
}

module.exports = { MODELS, providerOf, listByTier, findById, tzForProvince };
