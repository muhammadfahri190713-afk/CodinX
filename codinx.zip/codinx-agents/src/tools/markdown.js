'use strict';

// Minimal markdown renderer for terminal output.
// Supports: headings, bold, italic, code spans, code blocks, lists, tables, links.

const { C } = require('../banner');

function renderInline(text) {
  if (!text) return '';
  let out = text;
  // inline code `xxx`
  out = out.replace(/`([^`]+)`/g, (m, p1) => C.fg.brightBlack + C.bg.white + ' ' + p1 + ' ' + C.reset);
  // bold **xxx** or __xxx__
  out = out.replace(/\*\*([^*]+)\*\*/g, (m, p1) => C.bold + p1 + C.reset);
  out = out.replace(/__([^_]+)__/g, (m, p1) => C.bold + p1 + C.reset);
  // italic *xxx* or _xxx_
  out = out.replace(/\*([^*]+)\*/g, (m, p1) => C.italic + p1 + C.reset);
  out = out.replace(/_([^_]+)_/g, (m, p1) => C.italic + p1 + C.reset);
  // links [text](url)
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (m, t, u) => C.fg.brightBlue + C.underline + t + C.reset + C.fg.gray + ' (' + u + ')' + C.reset);
  return out;
}

function renderTable(tableLines) {
  // Very basic markdown table -> ASCII
  const rows = tableLines.map((l) => l.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim()));
  if (rows.length < 2) return tableLines.join('\n');
  const headers = rows[0];
  const widths = headers.map((h, i) =>
    Math.max(
      String(h).length,
      ...rows.slice(2).map((r) => String(r[i] || '').length)
    )
  );
  const sep = '+' + widths.map((w) => '-'.repeat(w + 2)).join('+') + '+';
  let out = sep + '\n';
  out += '| ' + headers.map((h, i) => String(h).padEnd(widths[i])).join(' | ') + ' |\n';
  out += sep + '\n';
  for (const r of rows.slice(2)) {
    out += '| ' + r.map((c, i) => String(c || '').padEnd(widths[i])).join(' | ') + ' |\n';
  }
  out += sep + '\n';
  return out;
}

function renderMarkdown(md) {
  if (!md) return '';
  const lines = md.split('\n');
  let out = '';
  let inCode = false;
  let codeLang = '';
  let codeBuf = [];
  let tableBuf = [];
  let inList = false;

  function flushTable() {
    if (tableBuf.length) {
      out += renderTable(tableBuf) + '\n';
      tableBuf = [];
    }
  }
  function flushCode() {
    if (codeBuf.length) {
      out += C.fg.brightGreen + '```' + (codeLang || '') + C.reset + '\n';
      out += C.fg.brightBlack + codeBuf.join('\n') + C.reset + '\n';
      out += C.fg.brightGreen + '```' + C.reset + '\n\n';
      codeBuf = [];
    }
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // code fence
    if (line.trim().startsWith('```')) {
      if (!inCode) {
        flushTable();
        inCode = true;
        codeLang = line.trim().slice(3);
        codeBuf = [];
      } else {
        flushCode();
        inCode = false;
        codeLang = '';
      }
      continue;
    }
    if (inCode) {
      codeBuf.push(line);
      continue;
    }

    // table row (line containing |)
    if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
      tableBuf.push(line);
      inList = false;
      continue;
    } else if (tableBuf.length) {
      flushTable();
    }

    // headings
    const hMatch = line.match(/^(#{1,6})\s+(.*)$/);
    if (hMatch) {
      const level = hMatch[1].length;
      const text = hMatch[2];
      const colors = [C.fg.brightMagenta, C.fg.brightCyan, C.fg.brightBlue, C.fg.brightGreen, C.fg.brightYellow, C.fg.brightRed];
      out += '\n' + C.bold + colors[level - 1] + '#'.repeat(level) + ' ' + text + C.reset + '\n';
      inList = false;
      continue;
    }

    // horizontal rule
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(line.trim())) {
      out += C.fg.gray + '─'.repeat(50) + C.reset + '\n';
      inList = false;
      continue;
    }

    // blockquote
    if (line.trim().startsWith('>')) {
      out += C.fg.brightYellow + '│ ' + renderInline(line.trim().slice(1).trim()) + C.reset + '\n';
      inList = false;
      continue;
    }

    // bullet list
    if (/^\s*[-*+]\s+/.test(line)) {
      inList = true;
      out += C.fg.brightCyan + '  • ' + C.reset + renderInline(line.replace(/^\s*[-*+]\s+/, '')) + '\n';
      continue;
    }
    // numbered list
    if (/^\s*\d+\.\s+/.test(line)) {
      inList = true;
      out += C.fg.brightYellow + '  ' + line.match(/^\s*(\d+)\./)[1] + '. ' + C.reset + renderInline(line.replace(/^\s*\d+\.\s+/, '')) + '\n';
      continue;
    }

    if (line.trim() === '') {
      out += '\n';
      inList = false;
      continue;
    }
    out += renderInline(line) + '\n';
  }
  flushTable();
  flushCode();
  return out;
}

module.exports = { renderMarkdown, renderInline, renderTable };
