'use strict';

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const https = require('https');
const http = require('http');
const { URL } = require('url');
const { C } = require('../banner');
const perms = require('../permissions');

// Permission prompt resolver.
// Set by chat.js so tools can ask the user without needing direct rl access.
let _permissionPromptFn = null;

function setPermissionPromptFn(fn) {
  _permissionPromptFn = fn;
}

async function askPermission(toolKey, description) {
  // If tool already has a non-ask state, use that directly (no prompt).
  const settings = perms.loadSettings();
  const state = settings[toolKey] || 'ask';
  if (state === 'allow') return { allowed: true, permanent: true };
  if (state === 'deny')  return { allowed: false, permanent: true };

  if (_permissionPromptFn) {
    return await _permissionPromptFn(toolKey, description);
  }
  // Fallback: deny if no prompt fn set (safer default than allow)
  return { allowed: false, permanent: false, reason: 'No permission prompt configured' };
}

// ============== Tool: File creation ==============
async function toolCreateFile(args) {
  const allowed = await askPermission('file.write', `Create file: ${args.path}`);
  if (!allowed.allowed) {
    return { ok: false, reason: 'User denied file write.' + (allowed.permanent ? ' (DENY set — change via /settings)' : '') };
  }
  try {
    const fullPath = path.resolve(args.path);
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, args.content || '');
    return { ok: true, path: fullPath, bytes: (args.content || '').length };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ============== Tool: File read ==============
async function toolReadFile(args) {
  const allowed = await askPermission('file.read', `Read file: ${args.path}`);
  if (!allowed.allowed) {
    return { ok: false, reason: 'User denied file read.' };
  }
  try {
    const content = fs.readFileSync(path.resolve(args.path), 'utf8');
    return { ok: true, content };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ============== Tool: Table generation ==============
function toolTable(args) {
  const headers = args.headers || [];
  const rows = args.rows || [];
  const fmt = args.format || 'ascii';

  if (fmt === 'markdown') {
    let out = '| ' + headers.join(' | ') + ' |\n';
    out += '| ' + headers.map(() => '---').join(' | ') + ' |\n';
    for (const r of rows) out += '| ' + r.join(' | ') + ' |\n';
    return { ok: true, content: out, format: 'markdown' };
  }
  if (fmt === 'csv') {
    let out = headers.join(',') + '\n';
    for (const r of rows) out += r.join(',') + '\n';
    return { ok: true, content: out, format: 'csv' };
  }
  // ASCII table
  const widths = headers.map((h, i) => Math.max(String(h).length, ...rows.map((r) => String(r[i] ?? '').length)));
  const sep = '+' + widths.map((w) => '-'.repeat(w + 2)).join('+') + '+';
  let out = sep + '\n';
  out += '| ' + headers.map((h, i) => String(h).padEnd(widths[i])).join(' | ') + ' |\n';
  out += sep + '\n';
  for (const r of rows) {
    out += '| ' + r.map((c, i) => String(c ?? '').padEnd(widths[i])).join(' | ') + ' |\n';
  }
  out += sep + '\n';
  return { ok: true, content: out, format: 'ascii' };
}

// ============== Tool: Web fetch ==============
async function toolWebFetch(args) {
  const allowed = await askPermission('web.fetch', `Fetch URL: ${args.url}`);
  if (!allowed.allowed) {
    return { ok: false, reason: 'User denied web fetch.' };
  }
  return new Promise((resolve) => {
    try {
      const u = new URL(args.url);
      const lib = u.protocol === 'https:' ? https : http;
      const req = lib.get(
        {
          hostname: u.hostname,
          port: u.port || (u.protocol === 'https:' ? 443 : 80),
          path: u.pathname + (u.search || ''),
          headers: { 'User-Agent': 'CodinX/1.0.0' },
        },
        (res) => {
          let chunks = '';
          res.on('data', (c) => (chunks += c));
          res.on('end', () => resolve({ ok: true, status: res.statusCode, body: chunks.slice(0, 8192) }));
        }
      );
      req.on('error', (e) => resolve({ ok: false, error: e.message }));
      req.setTimeout(15000, () => {
        req.destroy();
        resolve({ ok: false, error: 'timeout' });
      });
    } catch (e) {
      resolve({ ok: false, error: e.message });
    }
  });
}

// ============== Tool: Shell exec ==============
async function toolExec(args) {
  const allowed = await askPermission('shell.exec', `Run command: ${args.cmd}`);
  if (!allowed.allowed) {
    return { ok: false, reason: 'User denied shell exec.' };
  }
  return new Promise((resolve) => {
    exec(args.cmd, { maxBuffer: 1024 * 1024 * 4 }, (err, stdout, stderr) => {
      if (err) {
        return resolve({ ok: false, error: err.message, stdout, stderr });
      }
      resolve({ ok: true, stdout, stderr });
    });
  });
}

// ============== Tool registry ==============
const REGISTRY = {
  'file.create': { run: toolCreateFile, desc: 'Create / overwrite a file. args: { path, content }' },
  'file.read':   { run: toolReadFile,   desc: 'Read a file. args: { path }' },
  'table':       { run: (a) => Promise.resolve(toolTable(a)), desc: 'Render a table. args: { headers, rows, format }' },
  'web.fetch':   { run: toolWebFetch,   desc: 'HTTP GET. args: { url }' },
  'shell.exec':  { run: toolExec,       desc: 'Run shell command. args: { cmd }' },
};

// Parse model output for tool-call blocks in the format:
//   <<<TOOL:toolname>>>{...json...}<<<END>>>
function parseToolCalls(text) {
  const calls = [];
  const re = /<<<TOOL:([a-z._]+)>>>\s*([\s\S]*?)\s*<<<END>>>/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const tool = m[1];
    let argsRaw = m[2].trim();
    let args = {};
    if (argsRaw) {
      try {
        args = JSON.parse(argsRaw);
      } catch {
        args = { raw: argsRaw };
      }
    }
    calls.push({ tool, args });
  }
  return calls;
}

async function runToolCall(call) {
  const entry = REGISTRY[call.tool];
  if (!entry) {
    return { ok: false, error: `Unknown tool: ${call.tool}` };
  }
  try {
    return await entry.run(call.args);
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

module.exports = { REGISTRY, parseToolCalls, runToolCall, setPermissionPromptFn, askPermission };
