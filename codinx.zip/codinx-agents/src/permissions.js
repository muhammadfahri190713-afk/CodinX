'use strict';

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { C } = require('./banner');
const { ensureDataDir, readJSON, writeJSON } = require('./auth');

// Permission system.
// Each tool has a key. The user can grant:
//   - "ask" (default) - prompt every time, yellow text
//   - "allow"        - always allow (Selalu izinkan)
//   - "deny"         - always deny
// Default tool keys:
const TOOL_KEYS = [
  'shell.exec',      // run shell commands
  'file.write',      // write/create files
  'file.read',       // read files
  'web.fetch',       // fetch URLs
  'web.access',      // general web access toggle
  'camera.access',   // camera access
  'mic.access',      // microphone
  'clipboard.read', // clipboard
  'network.tcp',    // raw network
];

function settingsFile() {
  return path.join(__dirname, '..', 'data', 'settings.json');
}

function loadSettings() {
  ensureDataDir();
  const def = {};
  for (const k of TOOL_KEYS) def[k] = 'ask';
  return readJSON(settingsFile(), def);
}

function saveSettings(s) {
  writeJSON(settingsFile(), s);
}

// Returns true if tool allowed (either pre-approved or user said yes now).
// If state is "ask", prompts the user with yellow text:
//   Iya  Tidak  Selalu izinkan
async function checkPermission(toolKey, description, rl) {
  const settings = loadSettings();
  const state = settings[toolKey] || 'ask';
  if (state === 'allow') return { allowed: true, permanent: true };
  if (state === 'deny')  return { allowed: false, permanent: true };

  // Ask. Yellow prompt per spec.
  process.stdout.write('\n' + C.bg.yellow + C.fg.black + C.bold);
  process.stdout.write(` ⚠ Permission Required `.padEnd(60) + ' ');
  process.stdout.write(C.reset + '\n');
  process.stdout.write(C.fg.yellow + C.bold);
  process.stdout.write(`  Tool   : ${toolKey}\n`);
  process.stdout.write(`  Action : ${description}\n`);
  process.stdout.write(`  Izinkan tool ini berjalan?\n`);
  process.stdout.write(`   [1] Iya   [2] Tidak   [3] Selalu izinkan\n`);
  process.stdout.write(`  > ` + C.reset);

  const answer = await new Promise((resolve) => rl.question('', resolve));
  const choice = (answer || '').trim();

  if (choice === '3') {
    settings[toolKey] = 'allow';
    saveSettings(settings);
    return { allowed: true, permanent: true };
  }
  if (choice === '1' || choice.toLowerCase() === 'y' || choice.toLowerCase() === 'iya') {
    return { allowed: true, permanent: false };
  }
  return { allowed: false, permanent: false };
}

function setPermission(toolKey, state) {
  const settings = loadSettings();
  settings[toolKey] = state;
  saveSettings(settings);
}

function resetAll() {
  const def = {};
  for (const k of TOOL_KEYS) def[k] = 'ask';
  saveSettings(def);
}

function showSettings() {
  const s = loadSettings();
  process.stdout.write('\n' + C.fg.brightCyan + C.bold + '  CodinX — Permission Settings\n' + C.reset);
  process.stdout.write(C.fg.gray + '  ' + '─'.repeat(48) + '\n' + C.reset);
  for (const k of TOOL_KEYS) {
    const v = s[k] || 'ask';
    const badge =
      v === 'allow' ? C.fg.brightGreen + '[ALLOW]' :
      v === 'deny'  ? C.fg.brightRed + '[DENY ]' :
      C.fg.brightYellow + '[ASK  ]';
    process.stdout.write(`  ${badge}${C.reset}  ${k}\n`);
  }
  process.stdout.write('\n');
}

module.exports = {
  TOOL_KEYS,
  loadSettings,
  saveSettings,
  checkPermission,
  setPermission,
  resetAll,
  showSettings,
};
