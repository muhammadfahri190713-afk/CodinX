'use strict';

// CodinX ASCII banner — opencode / claude-code style
const BANNER = String.raw`
  ____    _    ____   _    ____ _______ 
 / ___|  / \  |  _ \ / \  / ___|_   _|
| |     / _ \ | |_) / _ \| |     | |
| |___ / ___ \|  _ / ___ \ |___  | |
 \____/_/   \_\_|_/_/   \_\____| |_|
                                       Multi-Model AI Agent | v1.0.0
`;

// ANSI color helpers (zero-dependency)
const C = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  italic: '\x1b[3m',
  underline: '\x1b[4m',
  fg: {
    black: '\x1b[30m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    gray: '\x1b[90m',
    brightRed: '\x1b[91m',
    brightGreen: '\x1b[92m',
    brightYellow: '\x1b[93m',
    brightBlue: '\x1b[94m',
    brightMagenta: '\x1b[95m',
    brightCyan: '\x1b[96m',
  },
  bg: {
    black: '\x1b[40m',
    red: '\x1b[41m',
    green: '\x1b[42m',
    yellow: '\x1b[43m',
    blue: '\x1b[44m',
    magenta: '\x1b[45m',
    cyan: '\x1b[46m',
    white: '\x1b[47m',
  },
};

function colorize(text, ...colors) {
  return colors.join('') + text + C.reset;
}

function printBanner() {
  // Gradient-ish: cyan -> magenta line by line
  const lines = BANNER.split('\n');
  const palette = [
    C.fg.cyan,
    C.fg.brightCyan,
    C.fg.brightBlue,
    C.fg.brightMagenta,
    C.fg.magenta,
    C.fg.brightBlue,
    C.fg.brightCyan,
    C.fg.cyan,
  ];
  let i = 0;
  for (const line of lines) {
    const c = palette[i % palette.length];
    process.stdout.write(c + C.bold + line + C.reset + '\n');
    i++;
  }
  process.stdout.write(C.fg.yellow + C.bold + '  > CodinX Agent ready. Type /help for commands.\n' + C.reset);
  process.stdout.write(C.fg.gray + '  > 130+ models | Permission-aware | Memory-enabled | Dinar-tracked\n' + C.reset + '\n');
}

module.exports = { BANNER, C, colorize, printBanner };
