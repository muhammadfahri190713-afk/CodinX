'use strict';

const readline = require('readline');
const { C, printBanner } = require('./banner');
const { checkRootLocal, getUser, saveUser, ensureDataDir } = require('./auth');
const { MODELS, findById, tzForProvince, providerOf, listByTier } = require('./models');
const { streamChat } = require('./api');
const { startConversation, appendMessage, listConversations } = require('./memory');
const dinar = require('./dinar');
const perms = require('./permissions');
const { parseToolCalls, runToolCall, REGISTRY, setPermissionPromptFn } = require('./tools');
const { renderMarkdown } = require('./tools/markdown');
const { printHeader, showModels, showHelp } = require('./settings');
const { startServer } = require('./web/server');

// ============== Global state ==============
const state = {
  mode: 'menu',           // 'menu' | 'chat' | 'select-model' | 'settings'
  currentConv: null,
  currentModel: 'glm-4.5-flash',
  webServerStarted: false,
};

function clearScreen() {
  process.stdout.write('\x1b[2J\x1b[H');
}

// ============== Tier enforcement ==============
function tierRank(t) {
  return { FREE: 0, PRO: 1, MAX: 2 }[t] ?? 0;
}

function canUseModel(userTier, modelTier) {
  return tierRank(userTier) >= tierRank(modelTier);
}

// ============== Output helpers ==============
function out(s) {
  process.stdout.write(s);
}

function line(s = '') {
  out(s + '\n');
}

// ============== Main menu ==============
function showMainMenu() {
  clearScreen();
  printBanner();
  const user = getUser();
  const tier = user.tier || 'FREE';
  const tierColor = tier === 'MAX' ? C.fg.brightMagenta : tier === 'PRO' ? C.fg.brightCyan : C.fg.brightGreen;
  const model = findById(state.currentModel);
  const modelName = model ? model.name : state.currentModel;
  const modelTierColor = model ? tierBadgeColor(model.tier) : C.fg.gray;

  line('');
  out(tierColor + C.bold + '  ╔══ CodinX Main Menu ' + '═'.repeat(30) + '╗\n' + C.reset);
  out(C.fg.gray + '  ║ ' + C.reset);
  out(C.fg.gray + 'Tier: ' + C.reset + tierColor + C.bold + tier + C.reset);
  out(C.fg.gray + '  |  Model: ' + C.reset + modelTierColor + (model ? model.tier + ' ' : '') + C.reset + C.fg.brightBlue + modelName + C.reset);
  if (user.tier === 'FREE') {
    out(C.fg.gray + '  |  Dinar: ' + C.reset + C.fg.brightYellow + (user.dinar ?? 0) + '/1300' + C.reset);
  }
  line('');
  out(C.fg.gray + '  ║ ' + C.reset + C.fg.gray + 'Provinsi: ' + (user.province || 'default') + '  |  TZ: ' + tzForProvince(user.province) + C.reset + '\n');
  out(C.fg.gray + '  ╚' + '═'.repeat(46) + '╝\n' + C.reset);
  line('');
  line(C.fg.brightCyan + C.bold + '  Pilih aksi:' + C.reset);
  line('');
  line('    ' + C.fg.brightYellow + '1' + C.reset + '  Pilih Model              (ganti model aktif)');
  line('    ' + C.fg.brightYellow + '2' + C.reset + '  Mulai Chat              (langsung ngobrol dengan AI)');
  line('    ' + C.fg.brightYellow + '3' + C.reset + '  Settings & Permissions  (toggle tool access)');
  line('    ' + C.fg.brightYellow + '4' + C.reset + '  Lihat Semua Models     (130+ model)');
  line('    ' + C.fg.brightYellow + '5' + C.reset + '  Lihat Skills / Tools   (file, table, web, exec)');
  line('    ' + C.fg.brightYellow + '6' + C.reset + '  Buka Web UI            (localhost:3000)');
  line('    ' + C.fg.brightYellow + '7' + C.reset + '  Status Dinar           (sisa request hari ini)');
  line('    ' + C.fg.brightYellow + '8' + C.reset + '  Percakapan Tersimpan   (history memory)');
  line('    ' + C.fg.brightYellow + '9' + C.reset + '  Ubah Tier              (FREE/PRO/MAX)');
  line('    ' + C.fg.brightRed   + '0' + C.reset + '  Quit');
  line('');
  out(C.fg.brightYellow + C.bold + '  ❯ ' + C.reset);
}

// ============== Model selection screen ==============
function showModelPicker() {
  clearScreen();
  printHeader('Pilih Model');
  const user = getUser();
  const userTier = user.tier || 'FREE';

  // Show accessible models first, grouped by tier
  const accessible = MODELS.filter((m) => canUseModel(userTier, m.tier));
  const locked = MODELS.filter((m) => !canUseModel(userTier, m.tier));

  line(C.fg.brightGreen + '  ✦ Tier ' + userTier + ' — bisa dipakai (' + accessible.length + ' model)' + C.reset);
  line(C.fg.gray + '  ' + '─'.repeat(60) + C.reset);
  let idx = 1;
  for (const m of accessible) {
    const num = String(idx).padStart(3);
    const badge = tierBadge(m.tier);
    const cur = m.id === state.currentModel ? C.fg.brightYellow + ' ← aktif' + C.reset : '';
    out('  ' + C.fg.brightYellow + num + C.reset + ' ' + badge + ' ' + C.fg.brightBlue + m.id.padEnd(32) + C.reset + ' ' + m.name + cur + '\n');
    idx++;
  }

  if (locked.length > 0) {
    line('');
    line(C.fg.brightRed + '  ✦ Locked (tier terlalu rendah) — upgrade via menu 9' + C.reset);
    line(C.fg.gray + '  ' + '─'.repeat(60) + C.reset);
    for (const m of locked) {
      const badge = tierBadge(m.tier);
      out('  ' + C.fg.gray + '   ' + C.reset + ' ' + badge + ' ' + C.fg.gray + m.id.padEnd(32) + C.reset + ' ' + C.fg.gray + m.name + C.reset + '\n');
    }
  }

  line('');
  line(C.fg.gray + '  Cara pilih: ketik nomor (1-' + accessible.length + ') atau model id (mis. glm-4.7-flash)' + C.reset);
  line(C.fg.gray + '  atau ketik /back untuk kembali ke menu' + C.reset);
  line('');
  out(C.fg.brightYellow + C.bold + '  ❯ ' + C.reset);
}

function tierBadge(tier) {
  const c = tierBadgeColor(tier);
  return c + C.bold + '[' + tier.padEnd(4) + ']' + C.reset;
}

function tierBadgeColor(tier) {
  return tier === 'MAX' ? C.fg.brightMagenta :
         tier === 'PRO' ? C.fg.brightCyan :
         C.fg.brightGreen;
}

// ============== Settings screen ==============
function showSettingsScreen() {
  clearScreen();
  printHeader('Settings & Permissions');
  const s = perms.loadSettings();
  const user = getUser();
  line('  ' + C.fg.brightCyan + 'Tier: ' + C.reset + tierBadge(user.tier || 'FREE'));
  line('  ' + C.fg.brightCyan + 'Provinsi: ' + C.reset + (user.province || 'default') + C.fg.gray + ' (TZ: ' + tzForProvince(user.province) + ')' + C.reset);
  line('');
  line('  ' + C.fg.brightCyan + C.bold + 'Permission Toggles:' + C.reset);
  line(C.fg.gray + '  ' + '─'.repeat(60) + C.reset);
  perms.TOOL_KEYS.forEach((k, i) => {
    const v = s[k] || 'ask';
    const badge = v === 'allow' ? C.fg.brightGreen + ' [ALLOW] ' :
                  v === 'deny'  ? C.fg.brightRed + ' [DENY ] ' :
                  C.fg.brightYellow + ' [ASK  ] ';
    out('  ' + C.fg.brightYellow + String(i + 1).padStart(2) + C.reset + ' ' + badge + C.reset + ' ' + k + '\n');
  });
  line('');
  line(C.fg.gray + '  Perintah:' + C.reset);
  line(C.fg.gray + '    <nomor> allow|ask|deny   contoh: 1 allow' + C.reset);
  line(C.fg.gray + '    reset    →  reset semua ke ASK' + C.reset);
  line(C.fg.gray + '    /back    →  kembali ke menu' + C.reset);
  line('');
  out(C.fg.brightYellow + C.bold + '  ❯ ' + C.reset);
}

// ============== Skills list ==============
function showSkills() {
  clearScreen();
  printHeader('Skills / Tools');
  line('  Ketik ' + C.fg.brightYellow + '/skill <nama> <args>' + C.reset + ' untuk menjalankan langsung.');
  line('  Atau biarkan AI memanggil tool saat chat (auto-detected dari output).');
  line('');
  line(C.fg.gray + '  ' + '─'.repeat(60) + C.reset);
  const entries = Object.entries(REGISTRY);
  entries.forEach(([name, def], i) => {
    out('  ' + C.fg.brightYellow + String(i + 1).padStart(2) + C.reset + ' ' + C.fg.brightBlue + name.padEnd(14) + C.reset + ' ' + def.desc + '\n');
  });
  line('');
  line(C.fg.gray + '  Contoh:' + C.reset);
  line(C.fg.gray + '    /skill file.create {"path":"/tmp/hello.txt","content":"hi"}' + C.reset);
  line(C.fg.gray + '    /skill table {"headers":["a","b"],"rows":[["1","2"]]}' + C.reset);
  line(C.fg.gray + '    /skill shell.exec {"cmd":"ls -la"}' + C.reset);
  line('');
  out(C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
}

// ============== Chat prompt ==============
function printChatPrompt() {
  const user = getUser();
  const tier = user.tier || 'FREE';
  const tierColor = tier === 'MAX' ? C.fg.brightMagenta : tier === 'PRO' ? C.fg.brightCyan : C.fg.brightGreen;
  const din = user.tier === 'FREE' ? ` | Dinar ${user.dinar ?? 0}/1300` : '';
  const conv = state.currentConv ? ` | conv:${state.currentConv.id.slice(-6)}` : '';
  out('\n' + tierColor + C.bold + ` [${tier}]` + C.reset +
      C.fg.brightBlue + ` ${state.currentModel}` + C.reset +
      C.fg.gray + `${din}${conv}` + C.reset +
      '\n' + C.fg.brightYellow + ' ❯ ' + C.reset);
}

// ============== Streaming ==============
async function streamReply(model, messages, convId) {
  let full = '';
  out(C.fg.white);
  try {
    await streamChat({
      model,
      messages,
      conversationId: convId,
      onToken: (t) => {
        out(t);
        full += t;
      },
    });
    out(C.reset + '\n');
  } catch (e) {
    out(C.reset + '\n');
    out(C.fg.brightRed + '  [stream error] ' + e.message + '\n' + C.reset);
  }
  return full;
}

// ============== Chat handler ==============
async function handleChat(text) {
  const user = dinar.resetIfNeeded(getUser());

  // Tier check for current model
  const model = findById(state.currentModel);
  if (model && !canUseModel(user.tier, model.tier)) {
    out(C.fg.brightRed + '\n  ✗ Model ' + model.id + ' butuh tier ' + model.tier + '. Tier Anda: ' + user.tier + '.\n' + C.reset);
    out(C.fg.gray + '    Upgrade lewat menu 9, atau pilih model lain via menu 1.\n' + C.reset);
    return;
  }

  // Dinar check
  const can = dinar.canSpend(user);
  if (!can.ok) {
    out(C.fg.brightRed + '\n  ✗ Dinar habis (' + can.dinar + '/' + dinar.DINAR_PER_REQUEST + ' dibutuhkan).\n' + C.reset);
    out(C.fg.gray + '    Reset besok midnight (tz: ' + tzForProvince(user.province) + ').' + C.reset + '\n');
    return;
  }

  // Start conversation if needed
  if (!state.currentConv) {
    state.currentConv = startConversation(state.currentModel, user.province);
    out(C.fg.gray + '  (percakapan baru: ' + state.currentConv.id + ')\n' + C.reset);
  }

  appendMessage(state.currentConv, 'user', text);

  const reply = await streamReply(state.currentModel, state.currentConv.messages, state.currentConv.id);

  if (!reply) {
    out(C.fg.brightRed + '  [no reply from model]\n' + C.reset);
    return;
  }

  appendMessage(state.currentConv, 'assistant', reply);
  out('\n' + renderMarkdown(reply) + '\n');

  // Detect & run tool calls
  const calls = parseToolCalls(reply);
  if (calls.length) {
    for (const call of calls) {
      out(C.fg.brightMagenta + '\n  ⚙ Auto tool call: ' + call.tool + C.reset + '\n');
      const result = await runToolCall(call);
      if (result.ok) {
        out(C.fg.brightGreen + '  ✓ ' + JSON.stringify(result).slice(0, 400) + C.reset + '\n');
        appendMessage(state.currentConv, 'tool', JSON.stringify({ tool: call.tool, args: call.args, result }));
      } else {
        out(C.fg.brightRed + '  ✗ ' + (result.error || result.reason) + C.reset + '\n');
        appendMessage(state.currentConv, 'tool_error', JSON.stringify({ tool: call.tool, error: result.error || result.reason }));
      }
    }
  }

  // Charge Dinar
  dinar.spend(getUser());
}

// ============== Direct skill runner ==============
async function runSkillDirect(input) {
  // input: /skill <name> <json-args>
  const parts = input.split(/\s+/);
  const name = parts[1];
  if (!name) {
    out(C.fg.brightRed + '  Pakai: /skill <name> <json-args>\n' + C.reset);
    out(C.fg.gray + '  Contoh: /skill file.create {"path":"/tmp/x.txt","content":"hi"}\n' + C.reset);
    return;
  }
  if (!REGISTRY[name]) {
    out(C.fg.brightRed + '  Skill tidak dikenal: ' + name + '\n' + C.reset);
    out(C.fg.gray + '  Tersedia: ' + Object.keys(REGISTRY).join(', ') + '\n' + C.reset);
    return;
  }
  let args = {};
  const jsonPart = parts.slice(2).join(' ');
  if (jsonPart) {
    try { args = JSON.parse(jsonPart); }
    catch {
      // Accept simple k=v pairs
      const kvs = jsonPart.match(/(\w+)=("([^"]*)"|\S+)/g) || [];
      for (const kv of kvs) {
        const [k, ...rest] = kv.split('=');
        args[k] = rest.join('=').replace(/^"|"$/g, '');
      }
    }
  }
  out(C.fg.brightMagenta + '\n  ⚙ Run skill: ' + name + C.reset + '\n');
  out(C.fg.gray + '  Args: ' + JSON.stringify(args) + '\n' + C.reset);
  const result = await runToolCall({ tool: name, args });
  if (result.ok) {
    out(C.fg.brightGreen + '  ✓ Result:\n' + C.reset);
    if (typeof result.content === 'string') {
      out(result.content + '\n');
    } else {
      out(JSON.stringify(result, null, 2).slice(0, 2000) + '\n');
    }
  } else {
    out(C.fg.brightRed + '  ✗ ' + (result.error || result.reason) + '\n' + C.reset);
  }
}

// ============== Main line handler (state machine) ==============
async function handleLine(line_in) {
  const text = line_in.trim();

  if (state.mode === 'menu') {
    return handleMenuChoice(text);
  }
  if (state.mode === 'select-model') {
    return handleModelChoice(text);
  }
  if (state.mode === 'settings') {
    return handleSettingsChoice(text);
  }
  // mode === 'chat'
  return handleChatMode(text);
}

function handleMenuChoice(text) {
  const n = text.trim();
  switch (n) {
    case '1':
      state.mode = 'select-model';
      showModelPicker();
      return;
    case '2':
      state.mode = 'chat';
      clearScreen();
      printHeader('Chat Mode');
      out(C.fg.gray + '  Ketik pesan untuk AI. Command: /menu /help /model /skills /skill /dinar /clear /quit\n' + C.reset);
      out(C.fg.gray + '  Aktif model: ' + C.reset + C.fg.brightBlue + state.currentModel + C.reset + '\n');
      printChatPrompt();
      return;
    case '3':
      state.mode = 'settings';
      showSettingsScreen();
      return;
    case '4':
      clearScreen();
      showModels();
      out(C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
      state.mode = 'pause';
      return;
    case '5':
      showSkills();
      state.mode = 'pause';
      return;
    case '6':
      if (!state.webServerStarted) {
        startServer();
        state.webServerStarted = true;
      } else {
        out(C.fg.brightGreen + '\n  Web UI sudah berjalan: http://localhost:3000\n' + C.reset);
      }
      out(C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
      state.mode = 'pause';
      return;
    case '7': {
      const user = dinar.resetIfNeeded(getUser());
      out('\n' + C.fg.brightYellow + '  ' + dinar.statusString(user) + '\n' + C.reset);
      out(C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
      state.mode = 'pause';
      return;
    }
    case '8': {
      clearScreen();
      printHeader('Percakapan Tersimpan');
      const convs = listConversations();
      if (convs.length === 0) {
        out(C.fg.gray + '  (belum ada percakapan)\n' + C.reset);
      } else {
        for (const c of convs.slice(0, 15)) {
          out('  ' + C.fg.brightCyan + c.id + C.reset + '  ' + C.fg.brightBlue + c.model.padEnd(20) + C.reset + '  ' + c.createdAt + '\n');
        }
      }
      out('\n' + C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
      state.mode = 'pause';
      return;
    }
    case '9': {
      clearScreen();
      printHeader('Ubah Tier');
      out('  Tier saat ini: ' + tierBadge(getUser().tier || 'FREE') + '\n');
      out('  Ketik: FREE / PRO / MAX\n\n');
      out(C.fg.brightYellow + '  ❯ ' + C.reset);
      state.mode = 'select-tier';
      return;
    }
    case '0':
    case 'quit':
    case 'exit':
      out(C.fg.brightCyan + '\n  Sampai jumpa! CodinX out.\n' + C.reset);
      process.exit(0);
    default:
      out(C.fg.brightRed + '\n  Pilihan tidak dikenal: ' + text + '\n' + C.reset);
      out(C.fg.gray + '  Ketik 1-9 atau 0 untuk quit.\n' + C.reset);
      out(C.fg.brightYellow + C.bold + '  ❯ ' + C.reset);
  }
}

function handleModelChoice(text) {
  const t = text.trim();
  if (t === '/back' || t === 'exit' || t === 'q') {
    state.mode = 'menu';
    showMainMenu();
    return;
  }
  // Try as number first
  const user = getUser();
  const accessible = MODELS.filter((m) => canUseModel(user.tier, m.tier));
  let model = null;
  if (/^\d+$/.test(t)) {
    const n = parseInt(t, 10);
    if (n >= 1 && n <= accessible.length) {
      model = accessible[n - 1];
    } else {
      out(C.fg.brightRed + '\n  Nomor di luar rentang (1-' + accessible.length + ')\n' + C.reset);
      out(C.fg.brightYellow + '  ❯ ' + C.reset);
      return;
    }
  } else {
    model = findById(t);
    if (!model) {
      out(C.fg.brightRed + '\n  Model id tidak ditemukan: ' + t + '\n' + C.reset);
      out(C.fg.gray + '  Ketik nomor atau model id, atau /back\n' + C.reset);
      out(C.fg.brightYellow + '  ❯ ' + C.reset);
      return;
    }
    if (!canUseModel(user.tier, model.tier)) {
      out(C.fg.brightRed + '\n  ✗ Tier ' + user.tier + ' tidak bisa pakai model ' + model.tier + '.\n' + C.reset);
      out(C.fg.gray + '    Upgrade via menu 9, atau pilih model lain.\n' + C.reset);
      out(C.fg.brightYellow + '  ❯ ' + C.reset);
      return;
    }
  }
  state.currentModel = model.id;
  out(C.fg.brightGreen + '\n  ✓ Model aktif: ' + model.name + ' (' + model.id + ') [' + model.tier + ']\n' + C.reset);
  out(C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
  state.mode = 'pause';
}

function handleSettingsChoice(text) {
  const t = text.trim();
  if (t === '/back' || t === 'exit' || t === 'q') {
    state.mode = 'menu';
    showMainMenu();
    return;
  }
  if (t === 'reset') {
    perms.resetAll();
    out(C.fg.brightGreen + '\n  ✓ Semua permission di-reset ke ASK.\n' + C.reset);
    setTimeout(() => { state.mode = 'settings'; showSettingsScreen(); }, 800);
    return;
  }
  // Parse: <num> <state>
  const parts = t.split(/\s+/);
  if (parts.length === 2) {
    const num = parseInt(parts[0], 10);
    const st = parts[1].toLowerCase();
    if (num >= 1 && num <= perms.TOOL_KEYS.length && ['allow', 'ask', 'deny'].includes(st)) {
      const toolKey = perms.TOOL_KEYS[num - 1];
      perms.setPermission(toolKey, st);
      out(C.fg.brightGreen + '\n  ✓ ' + toolKey + ' → ' + st + '\n' + C.reset);
      setTimeout(() => { state.mode = 'settings'; showSettingsScreen(); }, 300);
      return;
    }
  }
  out(C.fg.brightRed + '\n  Format salah. Pakai: <nomor> allow|ask|deny\n' + C.reset);
  out(C.fg.gray + '  Contoh: 1 allow\n' + C.reset);
  out(C.fg.brightYellow + '  ❯ ' + C.reset);
}

async function handleChatMode(text) {
  if (text === '/menu' || text === '/back') {
    state.mode = 'menu';
    showMainMenu();
    return;
  }
  if (text === '/help' || text === '?') {
    showHelp();
    printChatPrompt();
    return;
  }
  if (text === '/models') {
    clearScreen();
    showModels();
    out(C.fg.gray + '  Tekan Enter untuk lanjut chat…' + C.reset);
    state.mode = 'pause-chat';
    return;
  }
  if (text === '/skills') {
    clearScreen();
    showSkills();
    out(C.fg.gray + '  Tekan Enter untuk lanjut chat…' + C.reset);
    state.mode = 'pause-chat';
    return;
  }
  if (text.startsWith('/skill ')) {
    await runSkillDirect(text);
    printChatPrompt();
    return;
  }
  if (text === '/dinar') {
    const user = dinar.resetIfNeeded(getUser());
    out(C.fg.brightYellow + '  ' + dinar.statusString(user) + '\n' + C.reset);
    printChatPrompt();
    return;
  }
  if (text === '/clear') {
    clearScreen();
    printChatPrompt();
    return;
  }
  if (text === '/quit' || text === '/exit') {
    out(C.fg.brightCyan + '\n  Sampai jumpa! CodinX out.\n' + C.reset);
    process.exit(0);
  }
  if (text.startsWith('/model ')) {
    const id = text.slice(7).trim();
    const m = findById(id);
    const user = getUser();
    if (!m) {
      out(C.fg.brightRed + '  Model tidak ditemukan: ' + id + '\n' + C.reset);
    } else if (!canUseModel(user.tier, m.tier)) {
      out(C.fg.brightRed + '  ✗ Tier ' + user.tier + ' tidak bisa pakai ' + m.tier + ' model.\n' + C.reset);
    } else {
      state.currentModel = m.id;
      out(C.fg.brightGreen + '  ✓ Model aktif: ' + m.name + ' (' + m.id + ')\n' + C.reset);
    }
    printChatPrompt();
    return;
  }
  if (text.startsWith('/tier ')) {
    const t = text.slice(6).trim().toUpperCase();
    if (!['FREE', 'PRO', 'MAX'].includes(t)) {
      out(C.fg.brightRed + '  Tier tidak valid. Pakai: /tier FREE|PRO|MAX\n' + C.reset);
    } else {
      const user = getUser();
      user.tier = t;
      if (t === 'FREE') user.dinar = dinar.DAILY_DINAR_FREE;
      saveUser(user);
      out(C.fg.brightGreen + '  ✓ Tier diubah ke ' + t + '\n' + C.reset);
    }
    printChatPrompt();
    return;
  }
  if (text === '') {
    printChatPrompt();
    return;
  }
  if (text.startsWith('/')) {
    out(C.fg.brightRed + '  Command tidak dikenal: ' + text + '\n' + C.reset);
    out(C.fg.gray + '  /menu /help /models /skills /skill /model /tier /dinar /clear /quit\n' + C.reset);
    printChatPrompt();
    return;
  }

  // Real chat message
  try {
    await handleChat(text);
  } catch (e) {
    out(C.fg.brightRed + '\n  [error] ' + e.message + '\n' + C.reset);
  }
  printChatPrompt();
}

// ============== Tier selection handler ==============
function handleTierChoice(text) {
  const t = (text || '').trim().toUpperCase();
  if (!['FREE', 'PRO', 'MAX'].includes(t)) {
    out(C.fg.brightRed + '\n  Tier tidak valid. Ketik FREE / PRO / MAX\n' + C.reset);
    out(C.fg.brightYellow + '  ❯ ' + C.reset);
    return;
  }
  const user = getUser();
  user.tier = t;
  if (t === 'FREE') user.dinar = dinar.DAILY_DINAR_FREE;
  saveUser(user);
  out(C.fg.brightGreen + '\n  ✓ Tier diubah ke ' + t + '\n' + C.reset);
  out(C.fg.gray + '  Tekan Enter untuk kembali ke menu…' + C.reset);
  state.mode = 'pause';
}

// ============== Pause handlers ==============
function handlePause(text) {
  // After pause, return to menu (or chat)
  if (state.mode === 'pause-chat') {
    state.mode = 'chat';
    printChatPrompt();
    return;
  }
  state.mode = 'menu';
  showMainMenu();
}

// ============== Permission prompt via state machine ==============
// Tools call this when they need user approval (state is 'ask').
// Returns Promise<{allowed: boolean, permanent: boolean}>.
function permissionPrompt(toolKey, description) {
  return new Promise((resolve) => {
    // Yellow prompt per spec
    out('\n' + C.bg.yellow + C.fg.black + C.bold);
    out(' ⚠ Permission Required '.padEnd(60) + ' ');
    out(C.reset + '\n');
    out(C.fg.yellow + C.bold);
    out(`  Tool   : ${toolKey}\n`);
    out(`  Action : ${description}\n`);
    out(`  Izinkan tool ini berjalan?\n`);
    out(`   [1] Iya   [2] Tidak   [3] Selalu izinkan\n`);
    out(`  > ` + C.reset);

    state.mode = 'awaiting-permission';
    state._permResolver = resolve;
    state._permToolKey = toolKey;
  });
}

function handlePermissionChoice(text) {
  const t = (text || '').trim();
  const resolve = state._permResolver;
  const toolKey = state._permToolKey;
  state._permResolver = null;
  state._permToolKey = null;
  if (!resolve) {
    state.mode = 'chat';
    printChatPrompt();
    return;
  }
  if (t === '3') {
    const settings = perms.loadSettings();
    settings[toolKey] = 'allow';
    perms.saveSettings(settings);
    out(C.fg.brightGreen + '\n  ✓ Allowed (permanent).\n' + C.reset);
    state.mode = 'chat';
    resolve({ allowed: true, permanent: true });
    printChatPrompt();
    return;
  }
  if (t === '1' || t.toLowerCase() === 'y' || t.toLowerCase() === 'iya') {
    out(C.fg.brightGreen + '\n  ✓ Allowed (once).\n' + C.reset);
    state.mode = 'chat';
    resolve({ allowed: true, permanent: false });
    printChatPrompt();
    return;
  }
  out(C.fg.brightRed + '\n  ✗ Denied.\n' + C.reset);
  state.mode = 'chat';
  resolve({ allowed: false, permanent: false });
  printChatPrompt();
}

// ============== Main ==============
async function main(argv = []) {
  // 1. Auth check
  const auth = checkRootLocal();
  if (!auth.ok) {
    process.stderr.write(C.fg.brightRed + C.bold + '\n  CodinX access denied.\n' + C.reset);
    process.stderr.write(C.fg.brightRed + '  ' + auth.reason + '\n' + C.reset);
    process.stderr.write(C.fg.gray + '  Hanya user "root@localhost" (atau root@<lainnya>) yang boleh menjalankan CodinX.\n\n' + C.reset);
    process.exit(1);
  }

  ensureDataDir();

  // 2. Seed user if first run (no interactive prompt)
  let user = getUser();
  if (!user || !user.province) {
    user = {
      province: 'jawa timur',
      tier: 'FREE',
      createdAt: new Date().toISOString(),
      requestsToday: 0,
      dinar: dinar.DAILY_DINAR_FREE,
      lastReset: new Date().toISOString(),
      lastResetDate: '',
    };
    saveUser(user);
  }
  user = dinar.resetIfNeeded(user);

  // 3. Web-only mode?
  if (argv.includes('--web-only')) {
    startServer();
    return;
  }

  // 4. Start CLI
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: true,
    prompt: '',
  });

  // Wire up the permission prompt to use our state machine
  setPermissionPromptFn(permissionPrompt);

  showMainMenu();

  rl.on('line', async (line_in) => {
    try {
      if (state.mode === 'awaiting-permission') {
        handlePermissionChoice(line_in);
        return;
      }
      if (state.mode === 'pause' || state.mode === 'pause-chat') {
        handlePause(line_in);
        return;
      }
      if (state.mode === 'select-tier') {
        handleTierChoice(line_in);
        return;
      }
      await handleLine(line_in);
    } catch (e) {
      out(C.fg.brightRed + '\n  [unexpected error] ' + (e && e.message) + '\n' + C.reset);
      out(C.fg.brightYellow + '  ❯ ' + C.reset);
    }
  });

  rl.on('SIGINT', () => {
    out('\n' + C.fg.brightCyan + '  Sampai jumpa! CodinX out.\n' + C.reset);
    process.exit(0);
  });
}

module.exports = {
  main,
  state,
  showMainMenu,
  showModelPicker,
  showSettingsScreen,
  showSkills,
  handleLine,
  handleMenuChoice,
  handleModelChoice,
  handleSettingsChoice,
  handleChatMode,
  handleTierChoice,
  canUseModel,
};

if (require.main === module) {
  main(process.argv.slice(2));
}
