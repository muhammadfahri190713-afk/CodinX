# CodinX

> Multi-model AI agent CLI with permission system, persistent memory, Dinar token tracking, and built-in localhost:3000 web UI.

Inspired by **OpenCode / Codex / Claude Code**.

---

## Quick Start

```bash
# 1. Unzip
unzip codinx-agents.zip
cd codinx-agents

# 2. Run
npm start
# or
node bin/codinx.js
# or after npm install -g .
codinx
```

The agent only runs when the current OS user is `root` and the host is `localhost` (or any `root@*`).

## Features

- 130+ models (Claude, GPT, Gemini, Grok, Deepseek, Qwen, GLM, Kimi, Minimax, Mistral, Cohere, Doubao, Llama, etc.)
- 3 user tiers: **FREE / PRO / MAX**
- Permission prompt (yellow) before every tool run: `Iya / Tidak / Selalu izinkan`
- Persistent memory (same chat ID across one conversation)
- Dinar token system: FREE users get **1300 Dinar/day**, **65 Dinar = 1 request**, resets at local midnight (by province)
- Tools: file create, table, markdown render, web fetch, run command
- Localhost web UI at `http://localhost:3000` with permission toggles
- Settings menu for granting/revoking tool access

## Configuration

| Field        | Value                                              |
| ------------ | -------------------------------------------------- |
| Endpoint     | `https://inttelix.vercel.app/api/v1`               |
| API Key      | `sk-itlx-...` (preconfigured)                      |

## Permission Toggles

Open the settings menu from the CLI (`/settings`) or visit `http://localhost:3000` to toggle:

- Web access
- Camera access
- File read / write
- Shell exec
- Network fetch

## License

MIT
